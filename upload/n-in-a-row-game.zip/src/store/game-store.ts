import { create } from 'zustand';
import type { CellValue, Player, GameStatus, Move, GameMode, PlayerScore, ScoreBreakdown } from '@/lib/game/types';
import type { FullAnalysis } from '@/lib/game/threat-classifier';

interface GameStats {
  simulations: number;
  thinkTimeMs: number;
  nodesExpanded: number;
}

interface GameStore {
  // Settings
  boardSize: number;
  winLength: number;
  playerFirst: boolean;
  simulations: number;
  gameMode: GameMode;
  autoMode: boolean;

  // Game state
  gameId: string | null;
  board: CellValue[][];
  currentPlayer: Player;
  playerPiece: Player;
  aiPiece: Player;
  status: GameStatus;
  winner: Player | 0 | null;
  winLine: [number, number][] | null;
  moveHistory: Move[];
  lastStats: GameStats | null;
  isThinking: boolean;
  hoverCell: [number, number] | null;
  lastMove: [number, number] | null;
  aiFirstMove: [number, number] | null;

  // Scoring mode
  playerScore: PlayerScore | null;
  aiScore: PlayerScore | null;
  lastPlayerMoveScore: ScoreBreakdown | null;
  lastAiMoveScore: ScoreBreakdown | null;

  // Learning data
  learningHistory: Array<{
    moveNumber: number;
    simulations: number;
    thinkTimeMs: number;
    nodesExpanded: number;
    treeReused: boolean;
    totalTreeNodes: number;
    bestMoveWinRate: number;
    bestMoveRaveRate: number;
    raveBeta: number;
    raveCoverage: number;
    priorTreeVisits: number;
    globalRaveCoverage: number;
    globalRaveTotalVisits: number;
    globalRaveBestRate: number;
    crossGameRaveInherited: boolean;
    crossGameRaveVisits: number;
  }> | null;
  lastLearning: {
    moveNumber: number;
    simulations: number;
    thinkTimeMs: number;
    nodesExpanded: number;
    treeReused: boolean;
    totalTreeNodes: number;
    bestMoveWinRate: number;
    bestMoveRaveRate: number;
    raveBeta: number;
    raveCoverage: number;
    priorTreeVisits: number;
    globalRaveCoverage: number;
    globalRaveTotalVisits: number;
    globalRaveBestRate: number;
    crossGameRaveInherited: boolean;
    crossGameRaveVisits: number;
  } | null;

  // Analysis
  analysis: FullAnalysis | null;

  // Cross-game learning
  crossGameLearning: { inherited: boolean; priorVisits: number; gamesContributed: number } | null;

  // UI state
  showArchInfo: boolean;
  isInitializing: boolean;
  pendingSettingsCommit: boolean;
  previewDuration: number; // seconds, 0 = always show
  analysisAutoCollapse: number; // seconds, 0 = always show

  // Training state
  isTraining: boolean;
  trainingProgress: string | null;
  trainingResult: {
    totalGames: number;
    totalConfigs: number;
    totalMs: number;
    results: Array<{
      config: { boardSize: number; winLength: number; gameMode: string; numGames: number };
      p1Wins: number;
      p2Wins: number;
      draws: number;
      totalMs: number;
      raveCoverage: number;
      raveTotalVisits: number;
    }>;
  } | null;

  // Actions
  setBoardSize: (size: number) => void;
  setWinLength: (len: number) => void;
  setPlayerFirst: (first: boolean) => void;
  setSimulations: (sims: number) => void;
  setGameMode: (mode: GameMode) => void;
  setAutoMode: (auto: boolean) => void;
  setHoverCell: (cell: [number, number] | null) => void;
  setShowArchInfo: (show: boolean) => void;
  setPreviewDuration: (s: number) => void;
  setAnalysisAutoCollapse: (s: number) => void;
  newGame: () => Promise<void>;
  makeMove: (row: number, col: number) => Promise<void>;
  commitPendingSettings: () => Promise<void>;
  runTraining: (allConfigs?: boolean) => Promise<void>;
  clearTrainingResult: () => void;
}

const DEFAULT_SETTINGS = {
  boardSize: 15,
  winLength: 5,
  playerFirst: true,
  simulations: 3000,
  gameMode: 'classic' as GameMode,
  autoMode: false,
};

const emptyBoard = (size: number): CellValue[][] =>
  Array.from({ length: size }, () => Array(size).fill(0) as CellValue[]);

export const useGameStore = create<GameStore>((set, get) => ({
  ...DEFAULT_SETTINGS,
  gameId: null,
  board: emptyBoard(15),
  currentPlayer: 1,
  playerPiece: 1,
  aiPiece: 2,
  status: 'idle',
  winner: null,
  winLine: null,
  moveHistory: [],
  lastStats: null,
  isThinking: false,
  hoverCell: null,
  lastMove: null,
  aiFirstMove: null,
  showArchInfo: false,
  isInitializing: false,
  previewDuration: 5,
  analysisAutoCollapse: 0,
  pendingSettingsCommit: false,
  isTraining: false,
  trainingProgress: null,
  trainingResult: null,
  learningHistory: null,
  lastLearning: null,
  playerScore: null,
  aiScore: null,
  lastPlayerMoveScore: null,
  lastAiMoveScore: null,
  crossGameLearning: null,
  analysis: null,

  setBoardSize: (size) => {
    const { winLength, boardSize: oldSize, playerFirst, gameMode } = get();
    if (size === oldSize) return;
    const winLen = Math.min(size, winLength);
    const newWinLen = Math.max(3, winLen);
    // Immediate local preview: rebuild board at new size, reset game state locally
    const newBoard = emptyBoard(size);
    const playerPiece: Player = playerFirst ? 1 : 2;
    set({
      boardSize: size,
      winLength: newWinLen,
      board: newBoard,
      status: 'idle' as const,
      winner: null,
      winLine: null,
      moveHistory: [],
      lastStats: null,
      isThinking: false,
      hoverCell: null,
      lastMove: null,
      aiFirstMove: null,
      currentPlayer: playerFirst ? 1 : 2,
      playerPiece,
      aiPiece: playerFirst ? 2 : 1,
      learningHistory: [],
      lastLearning: null,
      playerScore: gameMode === 'scoring' ? { total: 0, breakdown: { triples: 0, fours: 0, fives: 0, fullRows: 0, fullCols: 0, mainDiagonal: 0, antiDiagonal: 0, crossPatterns: 0, lineBreaks: 0, total: 0 } } : null,
      aiScore: gameMode === 'scoring' ? { total: 0, breakdown: { triples: 0, fours: 0, fives: 0, fullRows: 0, fullCols: 0, mainDiagonal: 0, antiDiagonal: 0, crossPatterns: 0, lineBreaks: 0, total: 0 } } : null,
      crossGameLearning: null,
      analysis: null,
      pendingSettingsCommit: true,
    });
  },
  setWinLength: (len) => {
    const { boardSize, winLength: oldLen, gameMode, playerFirst } = get();
    const newLen = Math.max(3, Math.min(boardSize, len));
    if (newLen === oldLen) return;
    // Win length change doesn't change board layout, but resets the game
    const newBoard = emptyBoard(boardSize);
    const playerPiece: Player = playerFirst ? 1 : 2;
    set({
      winLength: newLen,
      board: newBoard,
      status: 'idle' as const,
      winner: null,
      winLine: null,
      moveHistory: [],
      lastStats: null,
      isThinking: false,
      hoverCell: null,
      lastMove: null,
      aiFirstMove: null,
      currentPlayer: playerFirst ? 1 : 2,
      playerPiece,
      aiPiece: playerFirst ? 2 : 1,
      learningHistory: [],
      lastLearning: null,
      crossGameLearning: null,
      analysis: null,
      pendingSettingsCommit: true,
    });
  },
  setPlayerFirst: (first) => {
    const { playerFirst: oldFirst, boardSize, gameMode } = get();
    if (first === oldFirst) return;
    const newBoard = emptyBoard(boardSize);
    const playerPiece: Player = first ? 1 : 2;
    set({
      playerFirst: first,
      board: newBoard,
      status: 'idle' as const,
      winner: null,
      winLine: null,
      moveHistory: [],
      lastStats: null,
      isThinking: false,
      hoverCell: null,
      lastMove: null,
      aiFirstMove: null,
      currentPlayer: first ? 1 : 2,
      playerPiece,
      aiPiece: first ? 2 : 1,
      learningHistory: [],
      lastLearning: null,
      crossGameLearning: null,
      analysis: null,
      pendingSettingsCommit: true,
    });
  },
  setSimulations: (sims) => set({ simulations: sims }),
  setGameMode: (mode) => {
    const { gameMode: oldMode, boardSize, playerFirst } = get();
    if (mode === oldMode) return;
    const newBoard = emptyBoard(boardSize);
    const playerPiece: Player = playerFirst ? 1 : 2;
    set({
      gameMode: mode,
      board: newBoard,
      status: 'idle' as const,
      winner: null,
      winLine: null,
      moveHistory: [],
      lastStats: null,
      isThinking: false,
      hoverCell: null,
      lastMove: null,
      aiFirstMove: null,
      currentPlayer: playerFirst ? 1 : 2,
      playerPiece,
      aiPiece: playerFirst ? 2 : 1,
      learningHistory: [],
      lastLearning: null,
      playerScore: mode === 'scoring' ? { total: 0, breakdown: { triples: 0, fours: 0, fives: 0, fullRows: 0, fullCols: 0, mainDiagonal: 0, antiDiagonal: 0, crossPatterns: 0, lineBreaks: 0, total: 0 } } : null,
      aiScore: mode === 'scoring' ? { total: 0, breakdown: { triples: 0, fours: 0, fives: 0, fullRows: 0, fullCols: 0, mainDiagonal: 0, antiDiagonal: 0, crossPatterns: 0, lineBreaks: 0, total: 0 } } : null,
      crossGameLearning: null,
      analysis: null,
      pendingSettingsCommit: true,
    });
  },
  setAutoMode: (auto) => set({ autoMode: auto }),

  runTraining: async (allConfigs = false) => {
    const { boardSize, winLength, gameMode, simulations } = get();
    set({ isTraining: true, trainingProgress: 'Starting training…', trainingResult: null });

    try {
      const body: Record<string, unknown> = { numGames: 20 };
      if (allConfigs) {
        body.allConfigs = true;
      } else {
        body.boardSize = boardSize;
        body.winLength = winLength;
        body.gameMode = gameMode;
      }

      const res = await fetch('/api/game/train', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      if (!res.ok) throw new Error('Training request failed');
      const ct = res.headers.get('content-type') || '';
      if (!ct.includes('application/json')) throw new Error('Server returned non-JSON response');
      const data = await res.json();

      const seconds = (data.totalMs / 1000).toFixed(1);
      set({
        isTraining: false,
        trainingProgress: `Done! ${data.totalGames} games in ${seconds}s`,
        trainingResult: data,
      });
    } catch (error) {
      set({
        isTraining: false,
        trainingProgress: `Error: ${error}`,
      });
      console.error('Training failed:', error);
    }
  },

  clearTrainingResult: () => set({ trainingResult: null, trainingProgress: null }),
  setHoverCell: (cell) => set({ hoverCell: cell }),
  setShowArchInfo: (show) => set({ showArchInfo: show }),
  setPreviewDuration: (s) => set({ previewDuration: s }),
  setAnalysisAutoCollapse: (s) => set({ analysisAutoCollapse: s }),

  /**
   * Commit pending settings to server.
   * Called by a debounced effect — does NOT set isInitializing (board is already correct locally).
   * Silently creates a new server game with current settings.
   */
  commitPendingSettings: async () => {
    const { pendingSettingsCommit, boardSize, winLength, playerFirst, simulations, gameMode } = get();
    if (!pendingSettingsCommit) return;

    // Clear flag immediately to prevent duplicate calls
    set({ pendingSettingsCommit: false });

    try {
      const res = await fetch('/api/game/new', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ boardSize, winLength, playerFirst, simulations, gameMode }),
      });
      if (!res.ok) return;
      const ct = res.headers.get('content-type') || '';
      if (!ct.includes('application/json')) return;
      const data = await res.json();

      // Silently update server state — board is already showing correct size
      const firstAiMove = data.aiMove ? [data.aiMove.row, data.aiMove.col] as [number, number] : null;
      set({
        gameId: data.gameId,
        board: data.board,
        boardSize: data.boardSize,
        winLength: data.winLength,
        currentPlayer: data.currentPlayer,
        playerPiece: data.playerPiece,
        aiPiece: data.aiPiece,
        status: data.status,
        winner: data.winner,
        winLine: data.winLine,
        moveHistory: data.moveHistory,
        isThinking: false,
        lastMove: null,
        aiFirstMove: firstAiMove,
        learningHistory: [],
        lastLearning: null,
        playerScore: data.playerScore ?? null,
        aiScore: data.aiScore ?? null,
        crossGameLearning: data.crossGameLearning ?? null,
        analysis: data.analysis ?? null,
      });
    } catch (error) {
      console.warn('Settings commit failed, will retry on next interaction:', error);
      // Re-set pending so the idle retry effect picks it up
      set({ pendingSettingsCommit: true });
    }
  },

  newGame: async () => {
    const { boardSize, winLength, playerFirst, simulations, gameMode } = get();
    set({ isThinking: true, isInitializing: true, status: 'idle' });

    // Retry up to 3 times with exponential backoff
    let lastError: unknown = null;
    for (let attempt = 0; attempt < 3; attempt++) {
      try {
        if (attempt > 0) {
          await new Promise(r => setTimeout(r, 500 * Math.pow(2, attempt - 1)));
        }

        const res = await fetch('/api/game/new', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ boardSize, winLength, playerFirst, simulations, gameMode }),
        });
        const ct = res.headers.get('content-type') || '';
        if (!ct.includes('application/json')) throw new Error('Server returned non-JSON response');
        const data = await res.json();

        if (!res.ok) throw new Error(data.error || 'Failed to create game');

        const firstAiMove = data.aiMove ? [data.aiMove.row, data.aiMove.col] as [number, number] : null;

        set({
          gameId: data.gameId,
          board: data.board,
          boardSize: data.boardSize,
          winLength: data.winLength,
          currentPlayer: data.currentPlayer,
          playerPiece: data.playerPiece,
          aiPiece: data.aiPiece,
          status: 'playing',
          winner: null,
          winLine: null,
          moveHistory: data.moveHistory,
          lastStats: null,
          isThinking: false,
          isInitializing: false,
          hoverCell: null,
          lastMove: null,
          aiFirstMove: firstAiMove,
          learningHistory: [],
          lastLearning: null,
          playerScore: data.playerScore ?? null,
          aiScore: data.aiScore ?? null,
          lastPlayerMoveScore: null,
          lastAiMoveScore: null,
          crossGameLearning: data.crossGameLearning ?? null,
          analysis: data.analysis ?? null,
        });
        return; // success
      } catch (error) {
        lastError = error;
        console.warn(`Game creation attempt ${attempt + 1} failed:`, error);
      }
    }

    // All retries failed
    set({ isThinking: false, isInitializing: false, status: 'idle' });
    console.error('Failed to create game after 3 attempts:', lastError);
  },

  makeMove: async (row, col) => {
    const { gameId, isThinking, status, board, playerPiece, moveHistory, learningHistory, gameMode, playerScore, aiScore } = get();
    if (!gameId || isThinking || status !== 'playing') return;
    if (board[row][col] !== 0) return;

    // Optimistic update: show player's piece immediately
    const optimisticBoard = board.map(r => [...r] as CellValue[]);
    optimisticBoard[row][col] = playerPiece;
    const optimisticMove: Move = { row, col, player: playerPiece };
    const optimisticHistory = [...moveHistory, optimisticMove];

    set({
      isThinking: true,
      hoverCell: null,
      board: optimisticBoard,
      moveHistory: optimisticHistory,
      currentPlayer: (playerPiece === 1 ? 2 : 1) as Player,
      lastMove: [row, col],
    });

    try {
      const res = await fetch('/api/game/move', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ gameId, row, col }),
      });
      if (!res.ok) {
        let serverMsg = '';
        try { const errBody = await res.json(); serverMsg = errBody.error || ''; } catch {}
        const err = new Error(serverMsg || 'Move request failed');
        (err as Record<string, unknown>).status = res.status;
        throw err;
      }
      const ct = res.headers.get('content-type') || '';
      if (!ct.includes('application/json')) throw new Error('Server returned non-JSON response');
      const data = await res.json();

      const lastAiMove = data.aiMove
        ? [data.aiMove.row, data.aiMove.col] as [number, number]
        : null;

      const learning = data.learning ?? null;
      const history = learning ? [...(learningHistory ?? []), learning] : learningHistory;

      set({
        board: data.board,
        currentPlayer: data.currentPlayer,
        status: data.status,
        winner: data.winner,
        winLine: data.winLine,
        moveHistory: data.moveHistory,
        lastStats: data.stats,
        isThinking: false,
        lastMove: lastAiMove,
        aiFirstMove: null,
        lastLearning: learning,
        learningHistory: history,
        playerScore: data.playerScore ?? playerScore,
        aiScore: data.aiScore ?? aiScore,
        lastPlayerMoveScore: data.playerMoveScore ?? null,
        lastAiMoveScore: data.aiMoveScore ?? null,
        analysis: data.analysis ?? null,
      });
    } catch (error) {
      // Revert optimistic update on error
      set({
        isThinking: false,
        board,
        moveHistory,
        currentPlayer: playerPiece,
        lastMove: moveHistory.length > 0
          ? [moveHistory[moveHistory.length - 1].row, moveHistory[moveHistory.length - 1].col] as [number, number]
          : null,
        analysis: get().analysis, // preserve existing analysis
      });
      // Only log if it's a real server error, not a sandbox disconnect
      if (error instanceof Error && error.message.includes('Game not found')) {
        console.warn('Game lost on server, auto-restarting...');
        get().newGame();
      } else if (error instanceof Error && !error.message.includes('Failed to fetch') && !error.message.includes('fetch failed')) {
        console.error('Failed to make move:', error);
      }
    }
  },
}));
