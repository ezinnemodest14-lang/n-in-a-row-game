'use client';

import { useState, useEffect, useRef, useCallback } from 'react';
import { Board } from '@/components/game/Board';
import { Toolbar } from '@/components/game/Toolbar';
import { SettingsContent } from '@/components/game/Settings';
import { GameInfoContent } from '@/components/game/GameInfo';
import { ArchInfo } from '@/components/game/ArchInfo';
import { BottomPanel } from '@/components/game/AnalysisPanel';
import { QuickPreview } from '@/components/game/QuickPreview';
import { EvalBar } from '@/components/game/EvalBar';
import { useGameStore } from '@/store/game-store';
import {
  Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription,
} from '@/components/ui/sheet';
import { BrainCircuit } from 'lucide-react';

const HOVER_DELAY = 300;

export default function Home() {
  const {
    status, newGame, autoMode, isThinking, isInitializing,
    pendingSettingsCommit, commitPendingSettings,
  } = useGameStore();

  const [showSettings, setShowSettings] = useState(false);
  const [showStats, setShowStats] = useState(false);
  const [sidePanelHovered, setSidePanelHovered] = useState(false);
  const sideHoverTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  // ---- Unified right-column hover ----
  const clearSideTimer = useCallback(() => {
    if (sideHoverTimer.current) { clearTimeout(sideHoverTimer.current); sideHoverTimer.current = null; }
  }, []);

  const handleRightColEnter = useCallback(() => {
    clearSideTimer();
    setSidePanelHovered(true);
  }, [clearSideTimer]);

  const handleRightColLeave = useCallback(() => {
    clearSideTimer();
    sideHoverTimer.current = setTimeout(() => setSidePanelHovered(false), HOVER_DELAY);
  }, [clearSideTimer]);

  useEffect(() => { return () => clearSideTimer(); }, [clearSideTimer]);

  // ---- Game logic ----
  const commitTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  useEffect(() => {
    if (!pendingSettingsCommit) return;
    if (commitTimerRef.current) clearTimeout(commitTimerRef.current);
    commitTimerRef.current = setTimeout(() => { commitPendingSettings(); }, 400);
    return () => { if (commitTimerRef.current) clearTimeout(commitTimerRef.current); };
  }, [pendingSettingsCommit, commitPendingSettings]);

  const settingsSheetOpen = showSettings;
  const statsSheetOpen = showStats;
  const newGameFn = useCallback(() => { newGame(); }, [newGame]);

  useEffect(() => {
    if (status === 'idle' && !isThinking && !isInitializing && !pendingSettingsCommit) {
      const timer = setTimeout(() => { newGameFn(); }, 300);
      return () => clearTimeout(timer);
    }
  }, [status, isThinking, isInitializing, pendingSettingsCommit, newGameFn]);

  const autoModeTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  useEffect(() => {
    if (autoMode && !isThinking && (status === 'won' || status === 'lost' || status === 'draw')) {
      autoModeTimer.current = setTimeout(() => { newGameFn(); }, 1500);
    }
    return () => { if (autoModeTimer.current) clearTimeout(autoModeTimer.current); };
  }, [autoMode, status, isThinking, newGameFn]);

  const isGameOver = status === 'won' || status === 'lost' || status === 'draw';

  return (
    <div className='h-screen flex flex-col bg-gradient-to-b from-stone-50 to-amber-50/30'>
      <Toolbar onOpenSettings={() => setShowSettings(true)} onOpenStats={() => setShowStats(true)} />

      {/* ====== MAIN AREA: Board + EvalBar + Side Preview ====== */}
      <main className='flex-1 flex min-h-0 px-1 sm:px-2 relative overflow-hidden'>
        {/* Board — clean, no overlays */}
        <div className='flex-1 flex items-center justify-center min-w-0'>
          <Board />
        </div>

        {/* Right column: EvalBar + Side Preview — UNIFIED HOVER ZONE */}
        <div
          className='flex-shrink-0 relative flex items-stretch py-1'
          onMouseEnter={handleRightColEnter}
          onMouseLeave={handleRightColLeave}
        >
          <EvalBar isSidePanelVisible={sidePanelHovered} />
          <QuickPreview visible={sidePanelHovered} />
        </div>
      </main>

      {/* ====== BOTTOM: Unified panel (status + collapsible analysis + footer) ====== */}
      <BottomPanel />

      {autoMode && isGameOver && (
        <div className='fixed inset-0 pointer-events-none z-30 flex items-end justify-center pb-14'>
          <div className='flex items-center gap-2 px-4 py-2 rounded-full bg-black/60 text-white text-xs backdrop-blur-sm animate-pulse'>
            <BrainCircuit className='w-3.5 h-3.5' /> Auto mode · Next game soon...
          </div>
        </div>
      )}

      <Sheet open={settingsSheetOpen} onOpenChange={setShowSettings}>
        <SheetContent side='right' className='w-full sm:max-w-sm overflow-y-auto'>
          <SheetHeader>
            <SheetTitle className='text-sm'>Settings</SheetTitle>
            <SheetDescription className='text-xs'>Board updates as you adjust. Game restarts automatically.</SheetDescription>
          </SheetHeader>
          <div className='px-4 pb-8'><SettingsContent /></div>
        </SheetContent>
      </Sheet>

      <Sheet open={statsSheetOpen} onOpenChange={setShowStats}>
        <SheetContent side='left' className='w-full sm:max-w-sm overflow-y-auto'>
          <SheetHeader>
            <SheetTitle className='text-sm'>Game Info & Stats</SheetTitle>
            <SheetDescription className='text-xs'>AI analysis, learning progress, and move history.</SheetDescription>
          </SheetHeader>
          <div className='px-4 pb-8'><GameInfoContent /></div>
        </SheetContent>
      </Sheet>

      <ArchInfo />
    </div>
  );
}
