import { NextResponse } from 'next/server';
import { GameStateInternal, type Player, type GameMode } from '@/lib/game/types';
import { games, cleanupOldGames, emptyPlayerScore, getCrossGameRave, type ServerGame } from '@/lib/game/server-games';

export async function POST(request: Request) {
  try {
    cleanupOldGames();
    const body = await request.json();
    const { boardSize, winLength, playerFirst, simulations, gameMode } = body;

    const size = Math.max(3, Math.min(24, Math.floor(boardSize || 15)));
    const win = Math.max(3, Math.min(size, Math.floor(winLength || 5)));
    const sims = Math.max(100, Math.min(100000, Math.floor(simulations || 3000)));
    const pFirst = playerFirst !== false;
    const mode: GameMode = gameMode === 'scoring' ? 'scoring' : 'classic';

    const state = new GameStateInternal(size, win, 1, mode);
    const playerPiece: Player = pFirst ? 1 : 2;
    const aiPiece: Player = pFirst ? 2 : 1;

    // Cross-game learning: inherit GlobalRAVE from previous games with same config
    const { rave: globalRAVE, inherited, priorVisits } = getCrossGameRave(size, mode);

    const gameId = `game_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;

    const gameData: ServerGame = {
      state,
      playerPiece,
      aiPiece,
      moveHistory: [],
      status: 'playing',
      winner: null as Player | 0 | null,
      winLine: null as [number, number][] | null,
      simulations: sims,
      createdAt: Date.now(),
      gameMode: mode,
      mctsRoot: null,
      lastAiMove: null,
      globalRAVE,
      learningHistory: [],
      playerScore: emptyPlayerScore(),
      aiScore: emptyPlayerScore(),
    };

    games.set(gameId, gameData);

    let aiMove: { row: number; col: number; player: Player; pointsScored?: number } | null = null;
    if (!pFirst) {
      const center = Math.floor(size / 2);
      state.applyMove(center, center);
      gameData.moveHistory.push({ row: center, col: center, player: aiPiece });
      gameData.lastAiMove = state.idx(center, center);
      aiMove = { row: center, col: center, player: aiPiece };
    }

    return NextResponse.json({
      gameId,
      board: state.to2DArray(),
      boardSize: size,
      winLength: win,
      currentPlayer: state.currentPlayer,
      playerPiece,
      aiPiece,
      status: 'playing',
      winner: null,
      winLine: null,
      moveHistory: gameData.moveHistory,
      aiMove,
      gameMode: mode,
      playerScore: mode === 'scoring' ? gameData.playerScore : null,
      aiScore: mode === 'scoring' ? gameData.aiScore : null,
      // Tell the client about inherited learning
      crossGameLearning: {
        inherited,
        priorVisits,
        gamesContributed: 0,
      },
    });
  } catch (error) {
    console.error('Error creating game:', error);
    return NextResponse.json(
      { error: 'Failed to create game' },
      { status: 500 }
    );
  }
}
