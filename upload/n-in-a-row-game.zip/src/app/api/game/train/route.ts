import { NextResponse } from 'next/server';
import { getCrossGameRave, recordCrossGameCompletion, loadPretrainedRAVE } from '@/lib/game/server-games';
import { runTraining } from '@/lib/game/training-engine';

const ALL_BOARD_SIZES = [3, 5, 8, 9, 10, 15, 19, 24];
type GameMode = 'classic' | 'scoring';
const ALL_MODES: GameMode[] = ['classic', 'scoring'];

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const allConfigs = body.allConfigs === true;
    const numGames = Math.max(1, Math.min(100, Math.floor(body.numGames || 20)));

    const configs: Array<{boardSize:number;winLength:number;gameMode:GameMode;numGames:number}> = [];
    if (allConfigs) {
      for (const bs of ALL_BOARD_SIZES) {
        const dw = bs <= 5 ? 3 : 5;
        for (const gm of ALL_MODES) {
          configs.push({ boardSize: bs, winLength: Math.min(dw, bs), gameMode: gm, numGames });
        }
      }
    } else {
      const bs = Math.max(3, Math.min(24, Math.floor(body.boardSize || 15)));
      const wl = Math.max(3, Math.min(bs, Math.floor(body.winLength || 5)));
      const gm: GameMode = body.gameMode === 'scoring' ? 'scoring' : 'classic';
      configs.push({ boardSize: bs, winLength: wl, gameMode: gm, numGames });
    }

    const preload = loadPretrainedRAVE();

    const { results, totalGames, totalMs } = await runTraining(
      configs,
      (bs, gm) => getCrossGameRave(bs, gm, false),
      recordCrossGameCompletion
    );

    return NextResponse.json({ totalGames, totalConfigs: configs.length, totalMs, pretrained: preload, results });
  } catch (error) {
    return NextResponse.json({ error: 'Training failed', details: String(error) }, { status: 500 });
  }
}
