import { NextResponse } from 'next/server';
import { type Player, type ScoreBreakdown, type PlayerScore } from '@/lib/game/types';
import { runMCTS, pruneTree } from '@/lib/game/mcts';
import { games, cleanupOldGames, emptyPlayerScore, recordCrossGameCompletion, type LearningEntry, type ServerGame } from '@/lib/game/server-games';
import { ThreatBoard, buildScoringAnalysis, categorize, ThreatCategory, type FullAnalysis } from '@/lib/game/threat-classifier';

export async function POST(request: Request) {
  try {
    cleanupOldGames();
    const body = await request.json();
    const { gameId, row, col } = body;

    const game = games.get(gameId);
    if (!game) {
      return NextResponse.json({ error: 'Game not found. Start a new game.' }, { status: 404 });
    }

    if (game.status !== 'playing') {
      return NextResponse.json({ error: 'Game is over.' }, { status: 400 });
    }

    const { state, playerPiece, aiPiece, moveHistory, globalRAVE, gameMode } = game;

    if (state.currentPlayer !== playerPiece) {
      return NextResponse.json({ error: 'Not your turn.' }, { status: 400 });
    }

    if (!state.inBounds(row, col) || state.get(row, col) !== 0) {
      return NextResponse.json({ error: 'Invalid move.' }, { status: 400 });
    }

    // Apply player's move
    const playerMove = { row, col, player: playerPiece };
    state.applyMove(row, col);
    moveHistory.push(playerMove);

    // Score player's move in scoring mode
    let playerMoveScore: ScoreBreakdown | null = null;
    if (gameMode === 'scoring') {
      playerMoveScore = state.scoreMove(row, col, playerPiece);
      game.playerScore.total += playerMoveScore.total;
      game.playerScore.breakdown.triples += playerMoveScore.triples;
      game.playerScore.breakdown.fours += playerMoveScore.fours;
      game.playerScore.breakdown.fives += playerMoveScore.fives;
      game.playerScore.breakdown.fullRows += playerMoveScore.fullRows;
      game.playerScore.breakdown.fullCols += playerMoveScore.fullCols;
      game.playerScore.breakdown.mainDiagonal += playerMoveScore.mainDiagonal;
      game.playerScore.breakdown.antiDiagonal += playerMoveScore.antiDiagonal;
      game.playerScore.breakdown.crossPatterns += playerMoveScore.crossPatterns;
      game.playerScore.breakdown.lineBreaks += playerMoveScore.lineBreaks;
      (playerMove as Record<string, unknown>).pointsScored = playerMoveScore.total;
    }

    // Classic mode: check if player won
    if (gameMode === 'classic') {
      const playerWinLine = state.checkWinAt(row, col, playerPiece);
      if (playerWinLine) {
        game.status = 'lost';
        game.winner = playerPiece;
        game.winLine = playerWinLine;
        game.mctsRoot = null;
        recordCrossGameCompletion(state.boardSize, game.gameMode);
        return NextResponse.json({
          board: state.to2DArray(), currentPlayer: state.currentPlayer,
          status: 'won' as const, winner: playerPiece as Player, winLine: playerWinLine,
          playerMove, aiMove: null, moveHistory: [...moveHistory],
          stats: { simulations: 0, thinkTimeMs: 0, nodesExpanded: 0 },
          learning: null, gameMode,
          playerScore: gameMode === 'scoring' ? game.playerScore : null,
          aiScore: gameMode === 'scoring' ? game.aiScore : null,
          playerMoveScore, aiMoveScore: null, analysis: null,
        });
      }
    }

    // Check if board is full
    if (state.isFull()) {
      if (gameMode === 'scoring') {
        const pTotal = game.playerScore.total;
        const aTotal = game.aiScore.total;
        game.status = pTotal > aTotal ? 'won' : aTotal > pTotal ? 'lost' : 'draw';
        game.winner = pTotal > aTotal ? playerPiece : aTotal > pTotal ? aiPiece : 0;
      } else {
        game.status = 'draw'; game.winner = 0;
      }
      game.mctsRoot = null;
      recordCrossGameCompletion(state.boardSize, gameMode);
      return NextResponse.json({
        board: state.to2DArray(), currentPlayer: state.currentPlayer,
        status: game.status, winner: game.winner, winLine: null,
        playerMove, aiMove: null, moveHistory: [...moveHistory],
        stats: { simulations: 0, thinkTimeMs: 0, nodesExpanded: 0 },
        learning: null, gameMode,
        playerScore: gameMode === 'scoring' ? game.playerScore : null,
        aiScore: gameMode === 'scoring' ? game.aiScore : null,
        playerMoveScore, aiMoveScore: null, analysis: null,
      });
    }

    // ---- AI's turn ----
    let treeToUse: ReturnType<typeof pruneTree> = null;
    if (game.mctsRoot !== null && game.lastAiMove !== null) {
      treeToUse = pruneTree(game.mctsRoot as any, game.lastAiMove, state.idx(row, col));
    }

    const aiStartTime = performance.now();
    const boardSize = state.boardSize;
    const totalCells = boardSize * boardSize;
    const emptyCells = totalCells - state.moveCount;
    let timeLimitMs: number;
    if (boardSize <= 5) timeLimitMs = 3000;
    else if (boardSize <= 10) timeLimitMs = 5000;
    else if (boardSize <= 15) timeLimitMs = 8000;
    else timeLimitMs = 12000;
    if (emptyCells < 20) timeLimitMs = Math.min(timeLimitMs, 3000);

    const result = runMCTS(state, game.simulations, timeLimitMs, treeToUse, globalRAVE);
    const thinkTimeMs = Math.round(performance.now() - aiStartTime);

    // ---- TACTICAL SAFETY NET ----
    let tacticalOverride: number | null = null;
    let tacticalReason: string | undefined;
    const legal = state.legalMoves();
    const opponent: 1 | 2 = aiPiece === 1 ? 2 : 1;
    const winLen = state.winLength;
    const dirs: [number, number][] = [[0,1],[1,0],[1,1],[1,-1]];
    let forcedWin = -1;
    let forcedBlock = -1;

    for (const m of legal) {
      const [mr, mc] = state.toRowCol(m);
      for (const p of [aiPiece, opponent] as const) {
        let wins = false;
        for (const [dr, dc] of dirs) {
          let count = 1;
          for (let s = 1; s < winLen; s++) { const r=mr+dr*s, c=mc+dc*s; if (!state.inBounds(r,c) || state.get(r,c)!==p) break; count++; }
          for (let s = 1; s < winLen; s++) { const r=mr-dr*s, c=mc-dc*s; if (!state.inBounds(r,c) || state.get(r,c)!==p) break; count++; }
          if (count >= winLen) { wins = true; break; }
        }
        if (wins) {
          if (p === aiPiece && forcedWin === -1) forcedWin = m;
          else if (p === opponent && forcedBlock === -1) forcedBlock = m;
        }
      }
      if (forcedWin >= 0) break;
    }

    if (forcedWin >= 0) {
      tacticalOverride = forcedWin;
      const [fr, fc] = state.toRowCol(forcedWin);
      tacticalReason = `Tactical: claims win at ${coordStr(fc, fr, boardSize)}`;
    } else if (forcedBlock >= 0) {
      tacticalOverride = forcedBlock;
      const [fr, fc] = state.toRowCol(forcedBlock);
      tacticalReason = `Tactical: blocks opponent at ${coordStr(fc, fr, boardSize)}`;
    }

    const bestMove = tacticalOverride !== null ? tacticalOverride : result.bestMove;
    const [aiRow, aiCol] = state.toRowCol(bestMove);

    // SAFETY: Verify AI's chosen move is actually empty
    let actualAiRow = aiRow;
    let actualAiCol = aiCol;
    if (state.get(aiRow, aiCol) !== 0) {
      console.error(`AI selected occupied cell (${aiRow}, ${aiCol}), falling back`);
      const fallbackMoves = state.legalMoves();
      if (fallbackMoves.length === 0) {
        game.status = 'draw'; game.winner = 0; game.mctsRoot = null;
        return NextResponse.json({
          board: state.to2DArray(), currentPlayer: state.currentPlayer,
          status: 'draw', winner: 0, winLine: null,
          playerMove, aiMove: null, moveHistory: [...moveHistory],
          stats: { simulations: result.simulations, thinkTimeMs: Math.round(performance.now() - aiStartTime), nodesExpanded: result.nodesExpanded },
          learning: null, gameMode,
          playerScore: gameMode === 'scoring' ? game.playerScore : null,
          aiScore: gameMode === 'scoring' ? game.aiScore : null,
          playerMoveScore, aiMoveScore: null, analysis: null,
        });
      }
      const fallbackIdx = fallbackMoves[Math.floor(Math.random() * fallbackMoves.length)];
      [actualAiRow, actualAiCol] = state.toRowCol(fallbackIdx);
    }
    const aiMove = { row: actualAiRow, col: actualAiCol, player: aiPiece };
    state.applyMove(actualAiRow, actualAiCol);
    moveHistory.push(aiMove);

    // Score AI's move in scoring mode
    let aiMoveScore: ScoreBreakdown | null = null;
    if (gameMode === 'scoring') {
      aiMoveScore = state.scoreMove(actualAiRow, actualAiCol, aiPiece);
      game.aiScore.total += aiMoveScore.total;
      game.aiScore.breakdown.triples += aiMoveScore.triples;
      game.aiScore.breakdown.fours += aiMoveScore.fours;
      game.aiScore.breakdown.fives += aiMoveScore.fives;
      game.aiScore.breakdown.fullRows += aiMoveScore.fullRows;
      game.aiScore.breakdown.fullCols += aiMoveScore.fullCols;
      game.aiScore.breakdown.mainDiagonal += aiMoveScore.mainDiagonal;
      game.aiScore.breakdown.antiDiagonal += aiMoveScore.antiDiagonal;
      game.aiScore.breakdown.crossPatterns += aiMoveScore.crossPatterns;
      game.aiScore.breakdown.lineBreaks += aiMoveScore.lineBreaks;
      (aiMove as Record<string, unknown>).pointsScored = aiMoveScore.total;
    }

    // Store the MCTS root for next turn
    game.mctsRoot = result.root;
    game.lastAiMove = result.bestMove;

    // ---- BUILD ANALYSIS ----
    const threatBoard = new ThreatBoard(state.boardSize, state.winLength);
    threatBoard.buildFromBoard(state.to2DArray(), playerPiece, aiPiece);

    // Extract MCTS children for AI candidate moves
    // FIX: RAVE data for a child is stored on the PARENT node's raveVisits[child.move]
    let mctsChildren: Array<{move:number,visits:number,winRate:number,raveRate:number}> | undefined;
    if (result.root && result.root.children.length > 0) {
      const root = result.root;
      mctsChildren = root.children
        .filter(c => c.visits > 0)
        .sort((a, b) => b.visits - a.visits)
        .slice(0, 5)
        .map(c => ({
          move: c.move,
          visits: c.visits,
          winRate: c.visits > 0 ? (c.wins / c.visits * 100) : 0,
          // RAVE for this child lives on root.raveVisits[child.move]
          raveRate: (root.raveVisits[c.move] || 0) > 0
            ? (root.raveWins[c.move] || 0) / (root.raveVisits[c.move] || 1) * 100
            : 0,
        }));
    }

    const analysis = threatBoard.buildFullAnalysis(
      [actualAiRow, actualAiCol],
      mctsChildren,
      tacticalReason,
      playerPiece,
    );

    // Add scoring analysis if in scoring mode
    if (gameMode === 'scoring') {
      analysis.scoringAnalysis = buildScoringAnalysis(
        state, playerPiece, aiPiece, game.playerScore, game.aiScore, state.to2DArray(),
      );
    }

    // Record learning entry
    const learningEntry: LearningEntry = {
      moveNumber: moveHistory.length,
      simulations: result.simulations,
      thinkTimeMs,
      nodesExpanded: result.nodesExpanded,
      treeReused: result.treeReused,
      totalTreeNodes: result.totalTreeNodes,
      bestMoveWinRate: result.bestMoveWinRate,
      bestMoveRaveRate: result.bestMoveRaveRate,
      raveBeta: result.raveBeta,
      raveCoverage: result.raveCoverage,
      priorTreeVisits: result.priorTreeVisits,
      globalRaveCoverage: result.globalRaveCoverage,
      globalRaveTotalVisits: result.globalRaveTotalVisits,
      globalRaveBestRate: result.globalRaveBestRate,
      crossGameRaveInherited: false,
      crossGameRaveVisits: globalRAVE ? globalRAVE.totalVisits : 0,
    };
    game.learningHistory.push(learningEntry);

    // Check if AI won (classic mode)
    if (gameMode === 'classic') {
      const aiWinLine = state.checkWinAt(actualAiRow, actualAiCol, aiPiece);
      if (aiWinLine) {
        game.status = 'won'; game.winner = aiPiece; game.winLine = aiWinLine;
        game.mctsRoot = null;
        recordCrossGameCompletion(state.boardSize, gameMode);
        return NextResponse.json({
          board: state.to2DArray(), currentPlayer: state.currentPlayer,
          status: 'lost' as const, winner: aiPiece as Player, winLine: aiWinLine,
          playerMove, aiMove, moveHistory: [...moveHistory],
          stats: { simulations: result.simulations, thinkTimeMs, nodesExpanded: result.nodesExpanded },
          learning: learningEntry, gameMode,
          playerScore: game.playerScore, aiScore: game.aiScore,
          playerMoveScore, aiMoveScore, analysis,
        });
      }
    }

    // Check if board is full after AI move
    if (state.isFull()) {
      if (gameMode === 'scoring') {
        const pTotal = game.playerScore.total;
        const aTotal = game.aiScore.total;
        game.status = pTotal > aTotal ? 'won' : aTotal > pTotal ? 'lost' : 'draw';
        game.winner = pTotal > aTotal ? playerPiece : aTotal > pTotal ? aiPiece : 0;
      } else {
        game.status = 'draw'; game.winner = 0;
      }
      game.mctsRoot = null;
      recordCrossGameCompletion(state.boardSize, gameMode);
      return NextResponse.json({
        board: state.to2DArray(), currentPlayer: state.currentPlayer,
        status: game.status, winner: game.winner, winLine: null,
        playerMove, aiMove, moveHistory: [...moveHistory],
        stats: { simulations: result.simulations, thinkTimeMs, nodesExpanded: result.nodesExpanded },
        learning: learningEntry, gameMode,
        playerScore: game.playerScore, aiScore: game.aiScore,
          playerMoveScore, aiMoveScore, analysis,
      });
    }

    return NextResponse.json({
      board: state.to2DArray(), currentPlayer: state.currentPlayer,
      status: 'playing' as const, winner: null, winLine: null,
      playerMove, aiMove, moveHistory: [...moveHistory],
      stats: { simulations: result.simulations, thinkTimeMs, nodesExpanded: result.nodesExpanded },
      learning: learningEntry, gameMode,
      playerScore: game.playerScore, aiScore: game.aiScore,
      playerMoveScore, aiMoveScore, analysis,
    });
  } catch (error) {
    console.error('Error processing move:', error);
    return NextResponse.json({ error: 'Failed to process move' }, { status: 500 });
  }
}

function coordStr(col: number, row: number, size: number): string {
  const letter = String.fromCharCode(65 + (col >= 8 ? col + 1 : col));
  return `${letter}${size - row}`;
}
