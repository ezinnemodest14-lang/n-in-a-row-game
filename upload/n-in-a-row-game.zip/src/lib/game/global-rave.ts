/**
 * GlobalRAVE: A position-level knowledge table that persists for the
 * entire game, independent of tree structure.
 *
 * Extracted from mcts.ts so lightweight endpoints (like training)
 * can import it without pulling in the full MCTS engine.
 */
export class GlobalRAVE {
  // Per-player arrays: visits[playerIdx][moveIdx], wins[playerIdx][moveIdx]
  // playerIdx: 0 = player 1, 1 = player 2
  visits: [Float64Array, Float64Array];
  wins: [Float64Array, Float64Array];
  totalMoves: number;
  totalUpdates: number;

  constructor(totalMoves: number) {
    this.totalMoves = totalMoves;
    this.visits = [new Float64Array(totalMoves), new Float64Array(totalMoves)];
    this.wins = [new Float64Array(totalMoves), new Float64Array(totalMoves)];
    this.totalUpdates = 0;
  }

  /** Update the global table with an AMAF entry */
  update(moveIdx: number, player: number, winner: number | 0): void {
    const pIdx = player - 1;
    this.visits[pIdx][moveIdx]++;
    if (winner === player) {
      this.wins[pIdx][moveIdx] += 1;
    } else if (winner === 0) {
      this.wins[pIdx][moveIdx] += 0.5;
    }
    this.totalUpdates++;
  }

  /** Get the win rate for a move by a player */
  getRate(moveIdx: number, player: number): number {
    const pIdx = player - 1;
    const v = this.visits[pIdx][moveIdx];
    if (v === 0) return 0.5;
    return this.wins[pIdx][moveIdx] / v;
  }

  /** Get visit count for a move by a player */
  getVisits(moveIdx: number, player: number): number {
    return this.visits[player - 1][moveIdx];
  }

  /** Get total entries with data across both players */
  get coverage(): number {
    let filled = 0;
    for (let i = 0; i < this.totalMoves; i++) {
      if (this.visits[0][i] > 0 || this.visits[1][i] > 0) filled++;
    }
    return filled;
  }

  /** Get total visits across all positions and players */
  get totalVisits(): number {
    let sum = 0;
    for (let p = 0; p < 2; p++) {
      for (let i = 0; i < this.totalMoves; i++) {
        sum += this.visits[p][i];
      }
    }
    return sum;
  }
}
