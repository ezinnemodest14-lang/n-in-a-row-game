// ============================================================
// Adaptive N-in-a-Row: MCTS Engine with RAVE (Layers 1 & 2)
// ============================================================
//
// Layer 1: Vanilla MCTS — rules-driven, aheuristic base reasoner.
//   Needs only legal_moves(state) and terminal_value(state).
//   Scales to any board size with zero retraining.
//
// Layer 2: RAVE (Rapid Action Value Estimation) — online self-adjustment.
//   Uses AMAF (All Moves As First) heuristic to share simulation
//   outcomes across sibling nodes, giving much faster convergence.
//
// Cross-Move Learning via Global RAVE Table:
//   Based on Gelly & Silver (2007) and Rimmel et al. (2010):
//   - A global RAVE table (per player, per board position) persists
//     for the ENTIRE GAME, independent of tree structure.
//   - During backpropagation, every simulation updates both the
//     tree nodes AND the global RAVE table.
//   - During UCT-RAVE selection, global RAVE is blended with
//     local node RAVE for robust position evaluation.
//   - During playouts, global RAVE biases move selection for
//     higher-quality simulations (Rimmel et al. 2010 technique).
//   - This survives tree pruning failures: even if the opponent's
//     move wasn't in the tree, global RAVE knowledge persists.
//   - Tree reuse is still attempted (for local RAVE + visit counts),
//     but learning no longer depends on it.
// ============================================================

import { GameStateInternal, MoveFeatures, Player, type CellValue } from './types';
import { GlobalRAVE } from './global-rave';

// ---- Constants ----
const EXPLORATION_CONSTANT = 1.414;  // UCT sqrt(2)
const RAVE_BETA_CONSTANT = 300;      // Controls RAVE vs standard mixing
const MAX_PLAYOUT_MOVES = 600;       // Safety cap for playouts
const GLOBAL_RAVE_WEIGHT = 0.3;      // Weight of global RAVE in selection blend

// ---- MCTS Node ----
export class MCTSNode {
  parent: MCTSNode | null;
  move: number;            // Flat index of the move that led here (-1 for root)
  playerJustMoved: Player; // Who played to reach this node
  children: MCTSNode[];
  untriedMoves: number[];  // Moves not yet expanded
  visits: number;
  wins: number;            // Wins for playerJustMoved
  totalMoves: number;      // Total possible moves (for array sizing)

  // Local RAVE statistics (path-specific, within tree)
  raveVisits: Float64Array;
  raveWins: Float64Array;

  lastSelectionBeta: number;

  constructor(
    parent: MCTSNode | null,
    move: number,
    playerJustMoved: Player,
    untriedMoves: number[],
    totalMoves: number
  ) {
    this.parent = parent;
    this.move = move;
    this.playerJustMoved = playerJustMoved;
    this.children = [];
    this.untriedMoves = untriedMoves;
    this.visits = 0;
    this.wins = 0;
    this.totalMoves = totalMoves;
    this.raveVisits = new Float64Array(totalMoves);
    this.raveWins = new Float64Array(totalMoves);
    this.lastSelectionBeta = 0;
  }

  /**
   * UCT-RAVE selection score with Global RAVE blending.
   * Combines three signals:
   *   1. Standard UCT (visit-based win rate)
   *   2. Local RAVE (tree-node AMAF, path-specific)
   *   3. Global RAVE (game-level AMAF, position-specific)
   */
  uctRaveScore(
    child: MCTSNode,
    logParentVisits: number,
    globalRAVE: GlobalRAVE | null
  ): { score: number; beta: number } {
    const visits = child.visits || 1;
    const qValue = child.wins / visits;

    // Local RAVE value from this (parent) node's RAVE stats
    const localRaveV = this.raveVisits[child.move] || 0;
    const localRaveW = this.raveWins[child.move] || 0;
    const qLocalRave = localRaveV > 0 ? localRaveW / localRaveV : 0.5;

    // Global RAVE value (persists across entire game)
    const playerToMoveAtNode: Player = this.playerJustMoved === 1 ? 2 : 1;
    let qGlobalRave = 0.5;
    let globalRaveWeight = 0;
    if (globalRAVE) {
      const gV = globalRAVE.getVisits(child.move, playerToMoveAtNode);
      if (gV > 0) {
        qGlobalRave = globalRAVE.getRate(child.move, playerToMoveAtNode);
        // Scale global weight by how much global data we have vs local
        globalRaveWeight = GLOBAL_RAVE_WEIGHT * Math.min(1, gV / 50);
      }
    }

    // Progressive bias: RAVE influence decreases as visit count grows
    const beta = Math.sqrt(RAVE_BETA_CONSTANT / (3 * visits + RAVE_BETA_CONSTANT));

    // Blend: (1-β)*UCT + β * [(1-gw)*localRAVE + gw*globalRAVE]
    const combinedRave = (1 - globalRaveWeight) * qLocalRave + globalRaveWeight * qGlobalRave;
    const combinedValue = (1 - beta) * qValue + beta * combinedRave;

    // UCT exploration bonus
    const exploration = EXPLORATION_CONSTANT * Math.sqrt(logParentVisits / visits);

    return { score: combinedValue + exploration, beta };
  }

  /** Select the best child using UCT-RAVE with Global RAVE */
  selectChild(globalRAVE: GlobalRAVE | null): { child: MCTSNode; beta: number } {
    const logVisits = Math.log(this.visits);
    let bestScore = -Infinity;
    let bestChild: MCTSNode = this.children[0];
    let bestBeta = 0;

    for (const child of this.children) {
      const { score, beta } = this.uctRaveScore(child, logVisits, globalRAVE);
      if (score > bestScore) {
        bestScore = score;
        bestChild = child;
        bestBeta = beta;
      }
    }

    return { child: bestChild, beta: bestBeta };
  }

  /** Add a child node for a given move */
  addChild(move: number, playerJustMoved: Player, untriedMoves: number[]): MCTSNode {
    const child = new MCTSNode(this, move, playerJustMoved, untriedMoves, this.totalMoves);
    this.children.push(child);
    return child;
  }

  /** Update this node with a simulation result */
  update(winner: Player | 0): void {
    this.visits++;
    if (winner === this.playerJustMoved) {
      this.wins += 1;
    } else if (winner === 0) {
      this.wins += 0.5;
    }
  }

  /** Find a child by move index */
  findChild(moveIdx: number): MCTSNode | undefined {
    return this.children.find(c => c.move === moveIdx);
  }
}

// ---- Feature Computation for Playout Policy ----

/** Compute move features for PPA-style playout biasing */
export function computeMoveFeatures(
  state: GameStateInternal,
  moveIdx: number
): MoveFeatures {
  const [row, col] = state.toRowCol(moveIdx);
  const player = state.currentPlayer;
  const opponent: Player = player === 1 ? 2 : 1;
  const size = state.boardSize;
  const winLen = state.winLength;

  let isWinning = false;
  let blocksWin = false;
  let maxLineCreated = 0;
  let maxLineBlocked = 0;
  let isOpenEnd = false;
  let ownAdjacent = 0;
  let oppAdjacent = 0;

  const directions: [number, number][] = [[0, 1], [1, 0], [1, 1], [1, -1]];

  for (const [dr, dc] of directions) {
    let ownCount = 0;
    let ownOpenEnds = 0;
    let oppCount = 0;

    // Positive direction (own)
    let openEnd = true;
    for (let step = 1; step < winLen; step++) {
      const r = row + dr * step;
      const c = col + dc * step;
      if (!state.inBounds(r, c)) { openEnd = false; break; }
      const v = state.get(r, c);
      if (v === player) ownCount++;
      else if (v === 0) { openEnd = true; break; }
      else { openEnd = false; break; }
    }
    if (openEnd && ownCount + 1 < winLen) ownOpenEnds++;

    // Negative direction (own)
    openEnd = true;
    for (let step = 1; step < winLen; step++) {
      const r = row - dr * step;
      const c = col - dc * step;
      if (!state.inBounds(r, c)) { openEnd = false; break; }
      const v = state.get(r, c);
      if (v === player) ownCount++;
      else if (v === 0) { openEnd = true; break; }
      else { openEnd = false; break; }
    }
    if (openEnd && ownCount + 1 < winLen) ownOpenEnds++;

    const ownLineLen = ownCount + 1;
    if (ownLineLen > maxLineCreated) {
      maxLineCreated = ownLineLen;
      isOpenEnd = ownOpenEnds > 0;
    }
    if (ownLineLen >= winLen) isWinning = true;

    // Positive direction (opponent)
    for (let step = 1; step < winLen; step++) {
      const r = row + dr * step;
      const c = col + dc * step;
      if (!state.inBounds(r, c)) break;
      const v = state.get(r, c);
      if (v === opponent) oppCount++;
      else break;
    }
    // Negative direction (opponent)
    for (let step = 1; step < winLen; step++) {
      const r = row - dr * step;
      const c = col - dc * step;
      if (!state.inBounds(r, c)) break;
      const v = state.get(r, c);
      if (v === opponent) oppCount++;
      else break;
    }

    if (oppCount + 1 > maxLineBlocked) maxLineBlocked = oppCount + 1;
    if (oppCount + 1 >= winLen) blocksWin = true;
  }

  // Adjacency
  for (let dr = -1; dr <= 1; dr++) {
    for (let dc = -1; dc <= 1; dc++) {
      if (dr === 0 && dc === 0) continue;
      const r = row + dr;
      const c = col + dc;
      if (state.inBounds(r, c)) {
        const v = state.get(r, c);
        if (v === player) ownAdjacent++;
        else if (v === opponent) oppAdjacent++;
      }
    }
  }

  // Center distance (normalized 0-1)
  const centerR = (size - 1) / 2;
  const centerC = (size - 1) / 2;
  const dist = Math.sqrt((row - centerR) ** 2 + (col - centerC) ** 2);
  const maxDist = Math.sqrt(centerR ** 2 + centerC ** 2);
  const centerDist = maxDist > 0 ? dist / maxDist : 0;

  // Scoring mode: count triples this move would create
  let triplesCreated = 0;
  let pointsScored = 0;
  if (state.gameMode === 'scoring') {
    // Simulate placing the piece
    const directions3: [number, number][] = [[0, 1], [1, 0], [1, 1], [1, -1]];
    for (const [dr, dc] of directions3) {
      let runLen = 1;
      for (let step = 1; ; step++) {
        const r = row + dr * step;
        const c = col + dc * step;
        if (!state.inBounds(r, c) || state.get(r, c) !== player) break;
        runLen++;
      }
      for (let step = 1; ; step++) {
        const r = row - dr * step;
        const c = col - dc * step;
        if (!state.inBounds(r, c) || state.get(r, c) !== player) break;
        runLen++;
      }
      if (runLen >= 3) {
        const newTriples = runLen - 2;
        triplesCreated += newTriples;
        pointsScored += newTriples; // 1 pt per triple
        if (runLen >= 4) pointsScored += (runLen - 3) * 5;
        if (runLen >= 5) pointsScored += (runLen - 4) * 15;
      }
    }
    // Override classic features for scoring mode
    isWinning = false;
    blocksWin = false;
    maxLineCreated = Math.min(triplesCreated + 2, 5);
    maxLineBlocked = 0;
  }

  return {
    isWinning,
    blocksWin,
    maxLineCreated,
    maxLineBlocked,
    isOpenEnd,
    ownAdjacent,
    oppAdjacent,
    centerDist,
    triplesCreated,
    pointsScored,
  };
}

/** Compute a heuristic score for a move (used in playout policy) */
function featureScore(features: MoveFeatures, winLen: number, isScoringMode: boolean = false): number {
  if (isScoringMode) {
    // Scoring mode: prioritize creating triples
    let score = features.pointsScored * 50;
    score += features.triplesCreated * 100;
    score += features.ownAdjacent * 8;
    score += features.oppAdjacent * 4;
    score += (1 - features.centerDist) * 15;
    return score;
  }

  if (features.isWinning) return 10000;
  if (features.blocksWin) return 9000;

  let score = 0;
  const lineCreated = features.maxLineCreated;
  const lineBlocked = features.maxLineBlocked;

  if (lineCreated === winLen - 1 && features.isOpenEnd) score += 500;
  else if (lineCreated === winLen - 1) score += 200;
  else if (lineCreated === winLen - 2 && features.isOpenEnd) score += 100;
  else if (lineCreated >= 2) score += lineCreated * 10;

  if (lineBlocked === winLen - 1) score += 400;
  else if (lineBlocked === winLen - 2) score += 80;
  else if (lineBlocked >= 2) score += lineBlocked * 8;

  score += features.ownAdjacent * 5;
  score += features.oppAdjacent * 3;
  score += (1 - features.centerDist) * 15;

  return score;
}

// ---- Playout Policy (Global RAVE + local RAVE + feature-weighted) ----

interface PlayoutAmafEntry {
  move: number;
  player: Player;
}

/**
 * Run a playout with Global RAVE biasing (Rimmel et al. 2010 technique).
 * Global RAVE significantly improves playout quality because it accumulates
 * knowledge from ALL previous simulations in the game, not just those
 * passing through the current tree node.
 */
function runPlayout(
  state: GameStateInternal,
  parentNode: MCTSNode | null,
  globalRAVE: GlobalRAVE | null
): { winner: Player | 0; amafMoves: PlayoutAmafEntry[] } {
  const amafMoves: PlayoutAmafEntry[] = [];
  const winLen = state.winLength;
  const totalCells = state.boardSize * state.boardSize;
  const isScoring = state.gameMode === 'scoring';
  let moveCount = 0;

  while (moveCount < MAX_PLAYOUT_MOVES && moveCount < totalCells) {
    const candidates = state.candidateMoves();
    if (candidates.length === 0) break;

    let chosenMove: number;

    // ============================================================
    // HARD TACTICAL OVERRIDES — Always checked first, both branches
    // ============================================================
    // These are forced regardless of RAVE or any other heuristic.
    // Winning move always takes priority. Blocking opponent's win
    // is second priority. Only if neither applies do we use scoring.
    // ============================================================
    let forcedWin = -1;
    let forcedBlock = -1;

    for (const m of candidates) {
      const features = computeMoveFeatures(state, m);
      if (features.isWinning) { forcedWin = m; break; }
      if (features.blocksWin && forcedBlock === -1) forcedBlock = m;
    }

    if (forcedWin >= 0) {
      chosenMove = forcedWin;
    } else if (forcedBlock >= 0) {
      chosenMove = forcedBlock;
    } else {
      // ============================================================
      // SOFT SELECTION — Feature scores + RAVE with softmax randomness
      // ============================================================
      // Use softmax sampling instead of greedy best-score.
      // This ensures DIVERSE playouts, which is critical for RAVE
      // to learn from varied game paths (Gelly & Silver 2007).
      // ============================================================
      const scores = new Float64Array(candidates.length);
      let maxScore = -Infinity;

      for (let i = 0; i < candidates.length; i++) {
        const m = candidates[i];
        const features = computeMoveFeatures(state, m);
        let score = featureScore(features, winLen, isScoring);

        // Blend with local RAVE (tree node) if available
        if (parentNode) {
          const raveV = parentNode.raveVisits[m] || 0;
          const raveW = parentNode.raveWins[m] || 0;
          if (raveV > 0) {
            const raveScore = raveW / raveV;
            const blendFactor = Math.min(0.25, raveV / 150);
            score = score * (1 - blendFactor) + raveScore * 500 * blendFactor;
          }
        }

        // Blend with Global RAVE (persists across entire game)
        if (globalRAVE) {
          const gV = globalRAVE.getVisits(m, state.currentPlayer);
          if (gV > 0) {
            const gRate = globalRAVE.getRate(m, state.currentPlayer);
            const blendFactor = Math.min(0.25, gV / 100);
            score = score * (1 - blendFactor) + gRate * 500 * blendFactor;
          }
        }

        scores[i] = score;
        if (score > maxScore) maxScore = score;
      }

      // Softmax sampling with temperature — higher temp = more random
      const temperature = candidates.length <= 10 ? 2.0 : 3.0;
      const probs = new Float64Array(candidates.length);
      let sumProbs = 0;
      for (let i = 0; i < candidates.length; i++) {
        probs[i] = Math.exp((scores[i] - maxScore) / temperature);
        sumProbs += probs[i];
      }
      let rand = Math.random() * sumProbs;
      chosenMove = candidates[0];
      for (let i = 0; i < candidates.length; i++) {
        rand -= probs[i];
        if (rand <= 0) { chosenMove = candidates[i]; break; }
      }
    }

    const [r, c] = state.toRowCol(chosenMove);
    const player = state.currentPlayer;
    state.applyMove(r, c);
    amafMoves.push({ move: chosenMove, player });
    moveCount++;

    // Classic mode: stop on win
    if (!isScoring) {
      const winner = state.checkTerminal(r, c);
      if (winner !== 0) return { winner, amafMoves };
    }
    // Both modes: stop when full
    if (state.isFull()) {
      if (isScoring) {
        const s1 = state.computeFullScore(1);
        const s2 = state.computeFullScore(2);
        return { winner: s1 > s2 ? 1 : s2 > s1 ? 2 : 0, amafMoves };
      }
      return { winner: 0, amafMoves };
    }
  }

  // Reached max playout moves without filling the board
  if (isScoring) {
    const s1 = state.computeFullScore(1);
    const s2 = state.computeFullScore(2);
    return { winner: s1 > s2 ? 1 : s2 > s1 ? 2 : 0, amafMoves };
  }
  return { winner: 0, amafMoves };
}

// ---- Learning Stats ----

export interface MCTSResult {
  root: MCTSNode;
  bestMove: number;
  simulations: number;
  nodesExpanded: number;
  // Learning metrics
  treeReused: boolean;
  totalTreeNodes: number;
  bestMoveWinRate: number;
  bestMoveRaveRate: number;
  raveBeta: number;
  raveCoverage: number;
  priorTreeVisits: number;
  // Global RAVE metrics
  globalRaveCoverage: number;
  globalRaveTotalVisits: number;
  globalRaveBestRate: number;
}

/** Walk the tree and count total nodes */
export function countTreeNodes(node: MCTSNode): number {
  let count = 1;
  for (const child of node.children) {
    count += countTreeNodes(child);
  }
  return count;
}

/** Compute RAVE coverage at root: % of children with RAVE data */
function computeRaveCoverage(root: MCTSNode): number {
  if (root.children.length === 0) return 0;
  let withRave = 0;
  for (const child of root.children) {
    if ((root.raveVisits[child.move] || 0) > 0) withRave++;
  }
  return withRave / root.children.length;
}

// ---- Main MCTS Function ----

/**
 * Run MCTS with RAVE + Global RAVE.
 *
 * Learning mechanisms (from strongest to weakest dependency on tree structure):
 *   1. Global RAVE Table (ALWAYS persists — the primary learning mechanism)
 *   2. Tree reuse with local RAVE (persists when opponent's move is in tree)
 *   3. Within-turn RAVE accumulation (always works within a single search)
 *
 * @param rootState Current game state
 * @param maxSimulations Max simulations to run
 * @param timeLimitMs Time budget in milliseconds
 * @param existingRoot Reused tree from previous turn (may be null)
 * @param globalRAVE Persistent Global RAVE table (the key learning mechanism)
 */
export function runMCTS(
  rootState: GameStateInternal,
  maxSimulations: number,
  timeLimitMs: number = 10000,
  existingRoot: MCTSNode | null = null,
  globalRAVE: GlobalRAVE | null = null
): MCTSResult {
  const startTime = performance.now();
  const totalMoves = rootState.boardSize * rootState.boardSize;
  const playerToMove = rootState.currentPlayer;
  const playerJustMoved: Player = playerToMove === 1 ? 2 : 1;

  const legal = rootState.legalMoves();
  if (legal.length === 0) {
    throw new Error('No legal moves available');
  }
  if (legal.length === 1) {
    const fallbackRoot = existingRoot || new MCTSNode(null, -1, playerJustMoved, legal, totalMoves);
    return {
      root: fallbackRoot,
      bestMove: legal[0],
      simulations: 1, nodesExpanded: 1,
      treeReused: !!existingRoot,
      totalTreeNodes: 1,
      bestMoveWinRate: 1, bestMoveRaveRate: 0.5,
      raveBeta: 1, raveCoverage: 0,
      priorTreeVisits: existingRoot?.visits || 0,
      globalRaveCoverage: globalRAVE ? globalRAVE.coverage / totalMoves : 0,
      globalRaveTotalVisits: globalRAVE?.totalVisits ?? 0,
      globalRaveBestRate: 0.5,
    };
  }

  let root: MCTSNode;
  const treeReused = existingRoot !== null;
  const priorTreeVisits = existingRoot?.visits || 0;

  if (existingRoot) {
    root = existingRoot;
  } else {
    const shuffled = [...legal];
    for (let i = shuffled.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
    }
    root = new MCTSNode(null, -1, playerJustMoved, shuffled, totalMoves);
  }

  let nodesExpanded = 0;
  let simulations = 0;
  let lastBeta = 1;

  for (let sim = 0; sim < maxSimulations; sim++) {
    if (sim % 256 === 0 && sim > 0) {
      const elapsed = performance.now() - startTime;
      if (elapsed >= timeLimitMs) break;
    }

    let node = root;
    let state = rootState.clone();

    // ---- 1. Selection (with Global RAVE) ----
    // Safety: skip children whose moves land on occupied cells (defense against stale tree)
    while (node.untriedMoves.length === 0 && node.children.length > 0) {
      let selectedChild: MCTSNode | null = null;
      let selectedBeta = 0;
      // Try up to all children; skip any whose move is occupied in the current state
      for (let attempt = 0; attempt < node.children.length; attempt++) {
        const { child, beta } = node.selectChild(globalRAVE);
        const [cr, cc] = state.toRowCol(child.move);
        if (state.get(cr, cc) === 0) {
          selectedChild = child;
          selectedBeta = beta;
          state.applyMove(cr, cc);
          break;
        }
        // This child's move is stale/occupied — temporarily remove from selection
        // by marking visits to 0 so selectChild won't pick it again
        child.visits = 0;
      }
      if (!selectedChild) break; // All children are stale, stop selection
      node = selectedChild;
      lastBeta = selectedBeta;
    }

    // ---- 2. Expansion ----
    // Safety: filter untriedMoves to only include actually empty cells
    if (node.untriedMoves.length > 0) {
      // Filter out any untried moves that are now occupied
      node.untriedMoves = node.untriedMoves.filter(m => {
        const [mr, mc] = state.toRowCol(m);
        return state.get(mr, mc) === 0;
      });

      if (node.untriedMoves.length > 0) {
        const moveIdx = Math.floor(Math.random() * node.untriedMoves.length);
        const move = node.untriedMoves[moveIdx];
        node.untriedMoves.splice(moveIdx, 1);

        const [r, c] = state.toRowCol(move);
        state.applyMove(r, c);
        nodesExpanded++;

        const childLegalMoves = state.legalMoves();
        for (let i = childLegalMoves.length - 1; i > 0; i--) {
          const j = Math.floor(Math.random() * (i + 1));
          [childLegalMoves[i], childLegalMoves[j]] = [childLegalMoves[j], childLegalMoves[i]];
        }
        const child = node.addChild(move, state.currentPlayer === 1 ? 2 : 1 as Player, childLegalMoves);
        node = child;
      }
    }

    // ---- 3. Simulation (Playout with Global RAVE biasing) ----
    const { winner, amafMoves } = runPlayout(state, node, globalRAVE);

    // ---- 4. Backpropagation ----
    // Update BOTH tree nodes (local RAVE) AND Global RAVE table
    let current: MCTSNode | null = node;
    while (current !== null) {
      current.update(winner);

      // Local RAVE update (tree-node level)
      const playerToMoveAtNode: Player = current.playerJustMoved === 1 ? 2 : 1;
      for (const entry of amafMoves) {
        if (entry.player === playerToMoveAtNode) {
          current.raveVisits[entry.move]++;
          if (winner === entry.player) {
            current.raveWins[entry.move] += 1;
          } else if (winner === 0) {
            current.raveWins[entry.move] += 0.5;
          }
        }
      }

      current = current.parent;
    }

    // Global RAVE update (game-level — THIS is what persists across turns)
    if (globalRAVE) {
      for (const entry of amafMoves) {
        globalRAVE.update(entry.move, entry.player, winner);
      }
    }

    simulations++;
  }

  // Select best move — with SAFETY: verify the cell is actually empty in the current state
  // This prevents selecting a stale child whose move is now occupied (e.g. by a reused tree)
  let bestChild: MCTSNode | null = null;
  let bestVisits = -1;
  for (const child of root.children) {
    const [cr, cc] = rootState.toRowCol(child.move);
    if (rootState.get(cr, cc) !== 0) continue; // Skip occupied cells
    if (child.visits > bestVisits) {
      bestVisits = child.visits;
      bestChild = child;
    }
  }

  // Fallback: if all children are stale, pick any legal move
  if (!bestChild) {
    const fallback = rootState.legalMoves();
    if (fallback.length > 0) {
      return {
        root,
        bestMove: fallback[Math.floor(Math.random() * fallback.length)],
        simulations, nodesExpanded,
        treeReused, totalTreeNodes: countTreeNodes(root),
        bestMoveWinRate: 0.5, bestMoveRaveRate: 0.5,
        raveBeta: lastBeta, raveCoverage: 0,
        priorTreeVisits,
        globalRaveCoverage: globalRAVE ? globalRAVE.coverage / totalMoves : 0,
        globalRaveTotalVisits: globalRAVE?.totalVisits ?? 0,
        globalRaveBestRate: 0.5,
      };
    }
  }

  const bestMoveWinRate = bestChild.wins / bestChild.visits;
  const bestRaveV = root.raveVisits[bestChild.move] || 0;
  const bestRaveW = root.raveWins[bestChild.move] || 0;
  const bestMoveRaveRate = bestRaveV > 0 ? bestRaveW / bestRaveV : 0.5;
  const { beta: bestBeta } = root.uctRaveScore(bestChild, Math.log(root.visits), globalRAVE);

  // Global RAVE stats for the best move
  const globalRaveBestRate = globalRAVE
    ? globalRAVE.getRate(bestChild.move, playerToMove)
    : 0.5;

  return {
    root,
    bestMove: bestChild.move,
    simulations,
    nodesExpanded,
    treeReused,
    totalTreeNodes: countTreeNodes(root),
    bestMoveWinRate,
    bestMoveRaveRate,
    raveBeta: bestBeta,
    raveCoverage: computeRaveCoverage(root),
    priorTreeVisits,
    globalRaveCoverage: globalRAVE ? globalRAVE.coverage / totalMoves : 0,
    globalRaveTotalVisits: globalRAVE?.totalVisits ?? 0,
    globalRaveBestRate,
  };
}

/**
 * Prune the tree: root → aiMoveChild → playerMoveChild.
 * Returns the grandchild as new root, or null if path not found.
 */
export function pruneTree(
  root: MCTSNode,
  aiMoveIdx: number,
  playerMoveIdx: number
): MCTSNode | null {
  const aiChild = root.findChild(aiMoveIdx);
  if (!aiChild) return null;

  const playerChild = aiChild.findChild(playerMoveIdx);
  if (!playerChild) return null;

  playerChild.parent = null;
  return playerChild;
}

/**
 * Single-level tree advance: root → moveChild.
 * Used as fallback when pruneTree fails (player's move not expanded).
 * Better than starting from scratch because the AI's subtree is preserved.
 */
export function advanceTree(root: MCTSNode, moveIdx: number): MCTSNode | null {
  const child = root.findChild(moveIdx);
  if (!child) return null;
  child.parent = null;
  return child;
}
