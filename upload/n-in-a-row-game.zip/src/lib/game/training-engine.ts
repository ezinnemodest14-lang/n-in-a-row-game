/**
 * Standalone training engine — ZERO project imports to avoid Turbopack crash.
 * Has its own type definitions and board logic.
 *
 * CRITICAL DESIGN: Playouts are RANDOM (not greedy) to produce diverse
 * move sequences. Only 2 tactical overrides: always take winning moves
 * and always block opponent's winning moves. This is the standard approach
 * for RAVE training (Gelly & Silver 2007, used in Crazy Stone, MoGo).
 *
 * RAVE (Rapid Action Value Estimation) works by tracking which moves
 * appear in winning vs losing games across many random playouts.
 * Diversity is ESSENTIAL — greedy playouts replay the same path
 * and produce no new statistical information.
 */

type Player = 1 | 2;
type GameMode = 'classic' | 'scoring';

export interface TrainConfig {
  boardSize: number;
  winLength: number;
  gameMode: GameMode;
  numGames: number;
}

export interface TrainResult {
  config: TrainConfig;
  p1Wins: number;
  p2Wins: number;
  draws: number;
  avgMoves: number;
  totalMs: number;
  raveCoverage: number;
  raveTotalVisits: number;
  newVisits: number;
  priorVisits: number;
}

// Re-declare GlobalRAVE interface (matches global-rave.ts exactly)
export interface IGlobalRAVE {
  visits: [Float64Array, Float64Array];
  wins: [Float64Array, Float64Array];
  update(moveIdx: number, player: number, winner: number | 0): void;
  getRate(moveIdx: number, player: number): number;
  getVisits(moveIdx: number, player: number): number;
  get coverage(): number;
  get totalVisits(): number;
}

class Board {
  cells: Uint8Array;
  size: number;
  moveCount: number;
  curPlayer: Player;
  winLen: number;
  mode: GameMode;

  constructor(size: number, winLen: number, mode: GameMode) {
    this.size = size;
    this.winLen = winLen;
    this.mode = mode;
    this.cells = new Uint8Array(size * size);
    this.moveCount = 0;
    this.curPlayer = 1;
  }

  idx(r: number, c: number) { return r * this.size + c; }
  get(r: number, c: number) { return this.cells[this.idx(r, c)]; }
  inBounds(r: number, c: number) { return r >= 0 && r < this.size && c >= 0 && c < this.size; }

  apply(r: number, c: number) {
    this.cells[this.idx(r, c)] = this.curPlayer;
    this.moveCount++;
    this.curPlayer = (this.curPlayer === 1 ? 2 : 1) as Player;
  }

  candidates(): number[] {
    if (this.moveCount === 0) {
      const c = Math.floor(this.size / 2);
      return [this.idx(c, c)];
    }
    const set = new Set<number>();
    const s = this.size;
    for (let i = 0; i < this.cells.length; i++) {
      if (this.cells[i] !== 0) {
        const r = Math.floor(i / s), c = i % s;
        for (let dr = -1; dr <= 1; dr++) {
          for (let dc = -1; dc <= 1; dc++) {
            if (!dr && !dc) continue;
            const nr = r + dr, nc = c + dc;
            if (nr >= 0 && nr < s && nc >= 0 && nc < s && this.cells[nr * s + nc] === 0)
              set.add(nr * s + nc);
          }
        }
      }
    }
    if (set.size > 0) return Array.from(set);
    const m: number[] = [];
    for (let i = 0; i < this.cells.length; i++) if (this.cells[i] === 0) m.push(i);
    return m;
  }

  /** Check if placing `player` at (r,c) would win */
  wouldWin(r: number, c: number, player: Player): boolean {
    const s = this.size, w = this.winLen;
    const ds = [[0,1],[1,0],[1,1],[1,-1]] as const;
    for (const [dr, dc] of ds) {
      let len = 1;
      for (let i = 1; i < w; i++) {
        const nr = r+dr*i, nc = c+dc*i;
        if (nr<0||nr>=s||nc<0||nc>=s||this.cells[nr*s+nc]!==player) break; len++;
      }
      for (let i = 1; i < w; i++) {
        const nr = r-dr*i, nc = c-dc*i;
        if (nr<0||nr>=s||nc<0||nc>=s||this.cells[nr*s+nc]!==player) break; len++;
      }
      if (len >= w) return true;
    }
    return false;
  }

  checkWin(r: number, c: number): Player | 0 {
    const p = this.get(r, c);
    if (p === 0) return 0;
    const s = this.size, w = this.winLen;
    const ds = [[0,1],[1,0],[1,1],[1,-1]] as const;
    for (const [dr, dc] of ds) {
      let len = 1;
      for (let i = 1; i < w; i++) {
        const nr = r+dr*i, nc = c+dc*i;
        if (nr<0||nr>=s||nc<0||nc>=s||this.get(nr,nc)!==p) break; len++;
      }
      for (let i = 1; i < w; i++) {
        const nr = r-dr*i, nc = c-dc*i;
        if (nr<0||nr>=s||nc<0||nc>=s||this.get(nr,nc)!==p) break; len++;
      }
      if (len >= w) return p as Player | 0;
    }
    return 0;
  }

  computeScore(p: Player): number {
    let total = 0;
    const s = this.size;
    const ds = [[0,1],[1,0],[1,1],[1,-1]] as const;
    for (let r = 0; r < s; r++) {
      for (let c = 0; c < s; c++) {
        if (this.get(r, c) !== p) continue;
        for (const [dr, dc] of ds) {
          const pr = r-dr, pc = c-dc;
          if (pr>=0&&pr<s&&pc>=0&&pc<s&&this.get(pr,pc)===p) continue;
          let len = 0, cr = r, cc = c;
          while (cr>=0&&cr<s&&cc>=0&&cc<s&&this.get(cr,cc)===p) { len++; cr+=dr; cc+=dc; }
          if (len >= 3) total += (len-2);
          if (len >= 4) total += (len-3)*5;
          if (len >= 5) total += (len-4)*15;
        }
      }
    }
    return total;
  }
}

/**
 * Play one game with RANDOM playouts + tactical overrides.
 *
 * This is the standard approach for RAVE training:
 * 1. Move selection is RANDOM from candidate positions
 * 2. ONLY override randomness for: immediate win, or block opponent's win
 * 3. This produces diverse game trajectories → RAVE learns statistical patterns
 *
 * RAVE works by observing: "when move X appears in a game where player P wins,
 * X gets credited." With random playouts, different games explore different paths,
 * giving X credit from many different contexts → robust statistical estimate.
 *
 * With greedy playouts (old code), the same path was replayed every time,
 * so RAVE just reinforced the heuristic's existing bias → zero new learning.
 */
function play(
  size: number, winLen: number, mode: GameMode, _rave: IGlobalRAVE
): { winner: Player | 0; moves: number } {
  const b = new Board(size, winLen, mode);
  const hist: Array<{m: number; p: Player}> = [];
  let winner: Player | 0 = 0;
  const ds = [[0,1],[1,0],[1,1],[1,-1]] as const;

  while (b.moveCount < size * size) {
    const cands = b.candidates();
    if (!cands.length) break;
    const player = b.curPlayer;
    const opp: Player = player === 1 ? 2 : 1;
    let chosen: number | null = null;

    // TACTICAL OVERRIDE 1: Take winning move if available
    for (const m of cands) {
      const r = (m / size) | 0, c = m % size;
      if (b.wouldWin(r, c, player)) {
        chosen = m;
        break;
      }
    }

    // TACTICAL OVERRIDE 2: Block opponent's winning move
    if (chosen === null) {
      for (const m of cands) {
        const r = (m / size) | 0, c = m % size;
        if (b.wouldWin(r, c, opp)) {
          chosen = m;
          break;
        }
      }
    }

    // RANDOM selection — the core of RAVE training
    if (chosen === null) {
      // Lightweight center-adjacency bias for slightly better games
      // (pure random on large boards produces too many scattered games)
      // But still MUCH more random than the old greedy approach
      const ctr = (size - 1) / 2;
      const scores = new Float64Array(cands.length);
      let maxS = -Infinity;
      for (let i = 0; i < cands.length; i++) {
        const r = (cands[i] / size) | 0;
        const c = cands[i] % size;
        // Tiny center bias (max ~2.0) just to prefer center region slightly
        const dist = Math.sqrt((r-ctr)**2 + (c-ctr)**2);
        scores[i] = ctr * 0.3 - dist * 0.3 + Math.random() * 20;
        if (scores[i] > maxS) maxS = scores[i];
      }
      // Softmax-ish selection: pick from top candidates randomly
      // Use temperature to control randomness (high = more random)
      const temperature = 5.0;
      let sum = 0;
      const probs = new Float64Array(cands.length);
      for (let i = 0; i < cands.length; i++) {
        probs[i] = Math.exp((scores[i] - maxS) / temperature);
        sum += probs[i];
      }
      let r = Math.random() * sum;
      for (let i = 0; i < cands.length; i++) {
        r -= probs[i];
        if (r <= 0) { chosen = cands[i]; break; }
      }
      if (chosen === null) chosen = cands[cands.length - 1];
    }

    const row = (chosen / size) | 0, col = chosen % size;
    b.apply(row, col);
    hist.push({m: chosen, p: player});

    if (mode === 'classic') {
      const w = b.checkWin(row, col);
      if (w) { winner = w; break; }
    }
  }

  if (mode === 'scoring' && !winner) {
    const s1 = b.computeScore(1), s2 = b.computeScore(2);
    winner = s1 > s2 ? 1 : s2 > s1 ? 2 : 0;
  }

  // AMAF update: for each move in the game, credit/debit based on outcome
  for (const e of hist) {
    _rave.update(e.m, e.p, winner);
  }

  return { winner, moves: hist.length };
}

export async function runTraining(
  configs: TrainConfig[],
  getRave: (bs: number, gm: GameMode) => { rave: IGlobalRAVE; priorVisits: number },
  recordDone: (bs: number, gm: GameMode) => void
): Promise<{ results: TrainResult[]; totalGames: number; totalMs: number }> {
  const results: TrainResult[] = [];
  const t0 = performance.now();

  for (const cfg of configs) {
    // Yield to event loop periodically
    if (cfg.boardSize >= 10) await new Promise(r => setTimeout(r, 0));

    const { rave, priorVisits } = getRave(cfg.boardSize, cfg.gameMode);
    const visitsBefore = rave.totalVisits;

    let p1=0, p2=0, dr=0, totalMoves=0;
    const c0 = performance.now();

    for (let g = 0; g < cfg.numGames; g++) {
      // Yield periodically for large boards to avoid blocking
      if (cfg.boardSize >= 15 && g > 0 && g % 3 === 0) {
        await new Promise(r => setTimeout(r, 0));
      }

      const res = play(cfg.boardSize, cfg.winLength, cfg.gameMode, rave);
      if (res.winner === 1) p1++;
      else if (res.winner === 2) p2++;
      else dr++;
      totalMoves += res.moves;
      recordDone(cfg.boardSize, cfg.gameMode);
    }

    const visitsAfter = rave.totalVisits;

    results.push({
      config: cfg,
      p1Wins: p1,
      p2Wins: p2,
      draws: dr,
      avgMoves: Math.round(totalMoves / cfg.numGames),
      totalMs: Math.round(performance.now() - c0),
      raveCoverage: rave.coverage,
      raveTotalVisits: Math.round(visitsAfter),
      newVisits: Math.round(visitsAfter - visitsBefore),
      priorVisits: Math.round(priorVisits),
    });
  }

  return {
    results,
    totalGames: results.reduce((s, r) => s + r.config.numGames, 0),
    totalMs: Math.round(performance.now() - t0),
  };
}
