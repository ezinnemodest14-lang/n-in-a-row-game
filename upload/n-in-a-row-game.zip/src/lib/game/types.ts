// ============================================================
// Adaptive N-in-a-Row: Type Definitions
// ============================================================

/** Board cell values */
export type CellValue = 0 | 1 | 2;

/** Player identifiers (1 = first player, 2 = second player) */
export type Player = 1 | 2;

/** Game status */
export type GameStatus = 'idle' | 'playing' | 'won' | 'lost' | 'draw';

/** Game mode */
export type GameMode = 'classic' | 'scoring';

/** A single move */
export interface Move {
  row: number;
  col: number;
  player: Player;
  pointsScored?: number;
}

/** Scoring breakdown for a move */
export interface ScoreBreakdown {
  triples: number;      // +1 per triple (3-in-a-row), overlapping counted
  fours: number;        // +5 per 4-in-a-row (bonus on top of triples)
  fives: number;        // +15 per 5-in-a-row (bonus on top of triples+fours)
  fullRows: number;     // +10 per fully filled row
  fullCols: number;     // +10 per fully filled column
  mainDiagonal: number; // +20 if entire main diagonal (TL→BR) is yours
  antiDiagonal: number; // +20 if entire anti-diagonal (TR→BL) is yours
  crossPatterns: number; // +3 per cross (horizontal + vertical runs of 3+ through stone)
  lineBreaks: number;    // +2 per opponent line broken (was 3+ before this placement)
  total: number;        // computed total
}

/** Score state for a player */
export interface PlayerScore {
  total: number;
  breakdown: ScoreBreakdown;
}

/** New game request */
export interface NewGameRequest {
  boardSize: number;
  winLength: number;
  playerFirst: boolean;
  simulations: number;
  gameMode?: GameMode;
}

/** Game state sent to client */
export interface GameState {
  gameId: string;
  board: CellValue[][];
  boardSize: number;
  winLength: number;
  currentPlayer: Player;
  playerPiece: Player;
  aiPiece: Player;
  status: GameStatus;
  winner: Player | 0 | null;
  winLine: [number, number][] | null;
  moveHistory: Move[];
  gameMode: GameMode;
  playerScore: PlayerScore | null;
  aiScore: PlayerScore | null;
}

/** Move request from client */
export interface MoveRequest {
  gameId: string;
  row: number;
  col: number;
}

/** Move response from server */
export interface MoveResponse {
  board: CellValue[][];
  currentPlayer: Player;
  status: GameStatus;
  winner: Player | 0 | null;
  winLine: [number, number][] | null;
  playerMove: Move;
  aiMove: Move | null;
  moveHistory: Move[];
  stats: {
    simulations: number;
    thinkTimeMs: number;
    nodesExpanded: number;
  };
  gameMode: GameMode;
  playerScore: PlayerScore | null;
  aiScore: PlayerScore | null;
  playerMoveScore: ScoreBreakdown | null;
  aiMoveScore: ScoreBreakdown | null;
}

/** Internal game state for MCTS (flat board for performance) */
export class GameStateInternal {
  board: Uint8Array;
  boardSize: number;
  winLength: number;
  currentPlayer: Player;
  moveCount: number;
  gameMode: GameMode;

  // Running scores in scoring mode
  scores: [number, number]; // [player1 total, player2 total]

  constructor(boardSize: number, winLength: number, currentPlayer: Player = 1, gameMode: GameMode = 'classic') {
    this.boardSize = boardSize;
    this.winLength = winLength;
    this.currentPlayer = currentPlayer;
    this.moveCount = 0;
    this.gameMode = gameMode;
    this.board = new Uint8Array(boardSize * boardSize);
    this.scores = [0, 0];
  }

  clone(): GameStateInternal {
    const copy = new GameStateInternal(this.boardSize, this.winLength, this.currentPlayer, this.gameMode);
    copy.board = new Uint8Array(this.board);
    copy.moveCount = this.moveCount;
    copy.scores = [this.scores[0], this.scores[1]];
    return copy;
  }

  idx(row: number, col: number): number {
    return row * this.boardSize + col;
  }

  get(row: number, col: number): CellValue {
    return this.board[this.idx(row, col)] as CellValue;
  }

  set(row: number, col: number, value: CellValue): void {
    this.board[this.idx(row, col)] = value;
  }

  inBounds(row: number, col: number): boolean {
    return row >= 0 && row < this.boardSize && col >= 0 && col < this.boardSize;
  }

  /** Apply a move and switch current player */
  applyMove(row: number, col: number): void {
    this.set(row, col, this.currentPlayer);
    this.moveCount++;
    this.currentPlayer = (this.currentPlayer === 1 ? 2 : 1) as Player;
  }

  /** Apply a move by flat index */
  applyMoveFlat(idx: number): void {
    this.board[idx] = this.currentPlayer;
    this.moveCount++;
    this.currentPlayer = (this.currentPlayer === 1 ? 2 : 1) as Player;
  }

  /** Get all legal moves (empty cells) */
  legalMoves(): number[] {
    const moves: number[] = [];
    for (let i = 0; i < this.board.length; i++) {
      if (this.board[i] === 0) moves.push(i);
    }
    return moves;
  }

  /** Get legal moves adjacent to existing pieces (for faster playouts) */
  candidateMoves(): number[] {
    if (this.moveCount === 0) {
      const center = Math.floor(this.boardSize / 2);
      return [this.idx(center, center)];
    }

    const candidates = new Set<number>();
    const size = this.boardSize;

    for (let i = 0; i < this.board.length; i++) {
      if (this.board[i] !== 0) {
        const row = Math.floor(i / size);
        const col = i % size;
        for (let dr = -1; dr <= 1; dr++) {
          for (let dc = -1; dc <= 1; dc++) {
            if (dr === 0 && dc === 0) continue;
            const nr = row + dr;
            const nc = col + dc;
            if (this.inBounds(nr, nc) && this.get(nr, nc) === 0) {
              candidates.add(this.idx(nr, nc));
            }
          }
        }
      }
    }

    return candidates.size > 0 ? Array.from(candidates) : this.legalMoves();
  }

  // ============================================================
  // SCORING MODE: Point-based evaluation
  // ============================================================

  /**
   * Score a move at (row, col) for the given player.
   * Returns a breakdown of all points earned.
   * 
   * Scoring rules:
   *   - Triple (3-in-a-row): +1 per unique triple (overlapping counted)
   *   - Four-in-a-row: +5 bonus (on top of triple points)
   *   - Five-in-a-row: +15 bonus (on top of triple+four points)
   *   - Full row (all cells): +10
   *   - Full column (all cells): +10
   *   - Full main diagonal (TL→BR): +20
   *   - Full anti-diagonal (TR→BL): +20
   */
  scoreMove(row: number, col: number, player: Player): ScoreBreakdown {
    const bd: ScoreBreakdown = {
      triples: 0,
      fours: 0,
      fives: 0,
      fullRows: 0,
      fullCols: 0,
      mainDiagonal: 0,
      antiDiagonal: 0,
      crossPatterns: 0,
      lineBreaks: 0,
      total: 0,
    };

    const size = this.boardSize;
    const opponent: Player = player === 1 ? 2 : 1;
    const directions: [number, number][] = [[0, 1], [1, 0], [1, 1], [1, -1]];
    const runLengths: number[] = [];

    // Check each direction for consecutive runs
    for (const [dr, dc] of directions) {
      // Find full run length through (row, col)
      let runLength = 1;

      // Positive direction
      for (let step = 1; ; step++) {
        const r = row + dr * step;
        const c = col + dc * step;
        if (!this.inBounds(r, c) || this.get(r, c) !== player) break;
        runLength++;
      }

      // Negative direction
      for (let step = 1; ; step++) {
        const r = row - dr * step;
        const c = col - dc * step;
        if (!this.inBounds(r, c) || this.get(r, c) !== player) break;
        runLength++;
      }

      runLengths.push(runLength);

      // Count overlapping triples within this run
      if (runLength >= 3) {
        const numTriples = runLength - 2; // e.g. 3→1, 4→2, 5→3
        bd.triples += numTriples;
      }
      if (runLength >= 4) {
        const numFours = runLength - 3; // e.g. 4→1, 5→2
        bd.fours += numFours;
      }
      if (runLength >= 5) {
        const numFives = runLength - 4; // e.g. 5→1, 6→2
        bd.fives += numFives;
      }
    }

    // Cross pattern: if horizontal (dir 0) AND vertical (dir 1) both have runs of 3+
    if (runLengths[0] >= 3 && runLengths[1] >= 3) {
      bd.crossPatterns = 1;
    }

    // Check full row
    let rowFull = true;
    for (let c = 0; c < size; c++) {
      if (this.get(row, c) !== player) { rowFull = false; break; }
    }
    if (rowFull) bd.fullRows = 1;

    // Check full column
    let colFull = true;
    for (let r = 0; r < size; r++) {
      if (this.get(r, col) !== player) { colFull = false; break; }
    }
    if (colFull) bd.fullCols = 1;

    // Check main diagonal (TL→BR): row === col
    if (row === col) {
      let diagFull = true;
      for (let i = 0; i < size; i++) {
        if (this.get(i, i) !== player) { diagFull = false; break; }
      }
      if (diagFull) bd.mainDiagonal = 1;
    }

    // Check anti-diagonal (TR→BL): row + col === size - 1
    if (row + col === size - 1) {
      let diagFull = true;
      for (let i = 0; i < size; i++) {
        if (this.get(i, size - 1 - i) !== player) { diagFull = false; break; }
      }
      if (diagFull) bd.antiDiagonal = 1;
    }

    // Line breaks: check if this placement breaks an opponent's run of 3+
    // For each direction, check if the opponent had a continuous run through this cell
    // before this move was placed (i.e., the cell is now player's but neighbors are opponent)
    for (const [dr, dc] of directions) {
      // Count opponent pieces in positive direction
      let oppPos = 0;
      for (let step = 1; ; step++) {
        const r = row + dr * step;
        const c = col + dc * step;
        if (!this.inBounds(r, c) || this.get(r, c) !== opponent) break;
        oppPos++;
      }
      // Count opponent pieces in negative direction
      let oppNeg = 0;
      for (let step = 1; ; step++) {
        const r = row - dr * step;
        const c = col - dc * step;
        if (!this.inBounds(r, c) || this.get(r, c) !== opponent) break;
        oppNeg++;
      }
      // If there were opponent pieces on both sides, this placement breaks their line
      if (oppPos >= 1 && oppNeg >= 1 && (oppPos + oppNeg) >= 2) {
        bd.lineBreaks++;
      }
    }

    // Compute total
    bd.total =
      bd.triples * 1 +
      bd.fours * 5 +
      bd.fives * 15 +
      bd.fullRows * 10 +
      bd.fullCols * 10 +
      bd.mainDiagonal * 20 +
      bd.antiDiagonal * 20 +
      bd.crossPatterns * 3 +
      bd.lineBreaks * 2;

    return bd;
  }

  /**
   * Fast score evaluation for MCTS playouts in scoring mode.
   * Returns points scored by the last move (simplified).
   */
  scoreMoveFast(row: number, col: number, player: Player): number {
    let points = 0;
    const directions: [number, number][] = [[0, 1], [1, 0], [1, 1], [1, -1]];
    const opponent: Player = player === 1 ? 2 : 1;
    const runLengths: number[] = [];

    for (const [dr, dc] of directions) {
      let runLength = 1;
      for (let step = 1; ; step++) {
        const r = row + dr * step;
        const c = col + dc * step;
        if (!this.inBounds(r, c) || this.get(r, c) !== player) break;
        runLength++;
      }
      for (let step = 1; ; step++) {
        const r = row - dr * step;
        const c = col - dc * step;
        if (!this.inBounds(r, c) || this.get(r, c) !== player) break;
        runLength++;
      }
      runLengths.push(runLength);
      if (runLength >= 3) points += (runLength - 2); // triples
      if (runLength >= 4) points += (runLength - 3) * 5; // fours bonus
      if (runLength >= 5) points += (runLength - 4) * 15; // fives bonus
    }
    // Cross pattern bonus
    if (runLengths[0] >= 3 && runLengths[1] >= 3) points += 3;
    // Line break bonus
    for (const [dr, dc] of directions) {
      let oppPos = 0;
      for (let step = 1; ; step++) {
        const r = row + dr * step;
        const c = col + dc * step;
        if (!this.inBounds(r, c) || this.get(r, c) !== opponent) break;
        oppPos++;
      }
      let oppNeg = 0;
      for (let step = 1; ; step++) {
        const r = row - dr * step;
        const c = col - dc * step;
        if (!this.inBounds(r, c) || this.get(r, c) !== opponent) break;
        oppNeg++;
      }
      if (oppPos >= 1 && oppNeg >= 1 && (oppPos + oppNeg) >= 2) points += 2;
    }
    return points;
  }

  /** Compute total score for a player by scanning the full board */
  computeFullScore(player: Player): number {
    let total = 0;
    const size = this.boardSize;
    const opponent: Player = player === 1 ? 2 : 1;
    const directions: [number, number][] = [[0, 1], [1, 0], [1, 1], [1, -1]];

    // Per-cell run lengths (for cross pattern detection)
    const hRun = new Uint8Array(size * size);
    const vRun = new Uint8Array(size * size);

    // Score all triples/fours/fives (avoid double-counting by scanning left-to-right, top-to-bottom)
    for (let r = 0; r < size; r++) {
      for (let c = 0; c < size; c++) {
        if (this.get(r, c) !== player) continue;

        for (let di = 0; di < directions.length; di++) {
          const [dr, dc] = directions[di];
          // Only count runs starting from this cell (prevent double counting)
          const prevR = r - dr;
          const prevC = c - dc;
          if (this.inBounds(prevR, prevC) && this.get(prevR, prevC) === player) continue;

          // Count run length
          let runLen = 0;
          let cr = r, cc = c;
          while (this.inBounds(cr, cc) && this.get(cr, cc) === player) {
            runLen++;
            // Store per-direction run length for cross detection
            if (di === 0) hRun[cr * size + cc] = runLen;
            if (di === 1) vRun[cr * size + cc] = runLen;
            cr += dr;
            cc += dc;
          }
          // Backfill the run length for all cells in the run
          if (di === 0) {
            let br = r, bc = c;
            for (let s = 0; s < runLen; s++) {
              hRun[br * size + bc] = runLen;
              br += dr; bc += dc;
            }
          }
          if (di === 1) {
            let br = r, bc = c;
            for (let s = 0; s < runLen; s++) {
              vRun[br * size + bc] = runLen;
              br += dr; bc += dc;
            }
          }

          if (runLen >= 3) total += (runLen - 2); // triples
          if (runLen >= 4) total += (runLen - 3) * 5; // fours
          if (runLen >= 5) total += (runLen - 4) * 15; // fives
        }
      }
    }

    // Cross patterns: cells where horizontal AND vertical runs are both >= 3
    for (let r = 0; r < size; r++) {
      for (let c = 0; c < size; c++) {
        if (this.get(r, c) !== player) continue;
        if (hRun[r * size + c] >= 3 && vRun[r * size + c] >= 3) {
          total += 3;
        }
      }
    }

    // Full rows
    for (let r = 0; r < size; r++) {
      let full = true;
      for (let c = 0; c < size; c++) {
        if (this.get(r, c) !== player) { full = false; break; }
      }
      if (full) total += 10;
    }

    // Full columns
    for (let c = 0; c < size; c++) {
      let full = true;
      for (let r = 0; r < size; r++) {
        if (this.get(r, c) !== player) { full = false; break; }
      }
      if (full) total += 10;
    }

    // Main diagonal (TL→BR)
    let mainFull = true;
    for (let i = 0; i < size; i++) {
      if (this.get(i, i) !== player) { mainFull = false; break; }
    }
    if (mainFull) total += 20;

    // Anti-diagonal (TR→BL)
    let antiFull = true;
    for (let i = 0; i < size; i++) {
      if (this.get(i, size - 1 - i) !== player) { antiFull = false; break; }
    }
    if (antiFull) total += 20;

    return total;
  }

  // ============================================================
  // CLASSIC MODE: Win/lose detection
  // ============================================================

  /**
   * Check if placing `player` at (row, col) wins the game.
   * Returns the winning line cells if it does, null otherwise.
   */
  checkWinAt(row: number, col: number, player: Player): [number, number][] | null {
    const size = this.boardSize;
    const winLen = this.winLength;
    const directions: [number, number][] = [[0, 1], [1, 0], [1, 1], [1, -1]];

    for (const [dr, dc] of directions) {
      const line: [number, number][] = [[row, col]];

      for (let step = 1; step < winLen; step++) {
        const r = row + dr * step;
        const c = col + dc * step;
        if (!this.inBounds(r, c) || this.get(r, c) !== player) break;
        line.push([r, c]);
      }

      for (let step = 1; step < winLen; step++) {
        const r = row - dr * step;
        const c = col - dc * step;
        if (!this.inBounds(r, c) || this.get(r, c) !== player) break;
        line.push([r, c]);
      }

      if (line.length >= winLen) return line;
    }

    return null;
  }

  /** Check if the last move wins (classic mode). Returns winner or 0. */
  checkTerminal(lastRow: number, lastCol: number): Player | 0 {
    const player = this.get(lastRow, lastCol);
    if (player === 0) return 0;
    return this.checkWinAt(lastRow, lastCol, player) ? player : 0;
  }

  /** Check if the board is full */
  isFull(): boolean {
    return this.moveCount >= this.boardSize * this.boardSize;
  }

  /** Convert flat index to [row, col] */
  toRowCol(idx: number): [number, number] {
    return [Math.floor(idx / this.boardSize), idx % this.boardSize];
  }

  /** Convert to 2D array for client */
  to2DArray(): CellValue[][] {
    const result: CellValue[][] = [];
    for (let r = 0; r < this.boardSize; r++) {
      result.push([]);
      for (let c = 0; c < this.boardSize; c++) {
        result[r].push(this.get(r, c));
      }
    }
    return result;
  }
}

/** Move features for PPA-style playout policy */
export interface MoveFeatures {
  isWinning: boolean;
  blocksWin: boolean;
  maxLineCreated: number;
  maxLineBlocked: number;
  isOpenEnd: boolean;
  ownAdjacent: number;
  oppAdjacent: number;
  centerDist: number;
  // Scoring mode features
  triplesCreated: number;  // How many new triples this move creates
  pointsScored: number;   // Approximate points this move scores
}
