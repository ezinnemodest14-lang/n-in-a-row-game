// ============================================================
// Threat Classifier & Position Analysis Engine v2
// ============================================================
// Key fix: per-player threat scanning instead of combined max.
// Each empty cell now stores the best/second-best consecutive count
// and open-end count SEPARATELY for each player.
// ============================================================

import type { Player, CellValue } from './types';

export enum ThreatCategory {
  NONE = 0,
  NON_FORCING = 1,
  SIMPLE_THREE = 2,
  BROKEN_THREE = 3,
  OPEN_THREE = 4,
  SIMPLE_FOUR = 5,
  OPEN_FOUR = 6,
  FIVE = 7,
}

const THREAT_INFO: Record<number, { name: string; color: string; severity: number }> = {
  [ThreatCategory.NONE]: { name: 'None', color: 'text-muted-foreground', severity: 0 },
  [ThreatCategory.NON_FORCING]: { name: 'Developing', color: 'text-muted-foreground', severity: 1 },
  [ThreatCategory.SIMPLE_THREE]: { name: 'Simple Three', color: 'text-amber-600', severity: 3 },
  [ThreatCategory.BROKEN_THREE]: { name: 'Broken Three', color: 'text-amber-500', severity: 3 },
  [ThreatCategory.OPEN_THREE]: { name: 'Open Three', color: 'text-orange-500', severity: 4 },
  [ThreatCategory.SIMPLE_FOUR]: { name: 'Simple Four', color: 'text-red-500', severity: 6 },
  [ThreatCategory.OPEN_FOUR]: { name: 'Open Four', color: 'text-red-600', severity: 7 },
  [ThreatCategory.FIVE]: { name: 'Five', color: 'text-red-700 font-bold', severity: 9 },
};

export interface PlayerBestMove {
  row: number;
  col: number;
  score: number;
  bestCat: ThreatCategory;
  secondCat: ThreatCategory;
  bestThreat: string;
  isFork: boolean;
  strategicScore: number;
  description: string;
  projectedPoints?: number;
}

export interface ScoringAnalysis {
  playerTotal: number;
  aiTotal: number;
  diff: number;
  topScoringMoves: Array<{ row: number; col: number; points: number; patterns: string }>;
  topAiScoringMoves: Array<{ row: number; col: number; points: number; patterns: string }>;
  playerPace: number;
  aiPace: number;
  remainingMoves: number;
  projectedPlayerFinal: number;
  projectedAiFinal: number;
  playerBreakdown: { triples: number; fours: number; fives: number; crosses: number; lineBreaks: number };
  aiBreakdown: { triples: number; fours: number; fives: number; crosses: number; lineBreaks: number };
  boardFillPct: number;
}

export interface CriticalSquare {
  row: number;
  col: number;
  reason: string;
  severity: 'vital' | 'important' | 'noteworthy';
  forPlayer: 'player' | 'ai' | 'both';
}

export interface FullAnalysis {
  evalScore: number;
  winProb: number;
  assessment: string;
  aiReasoning: string;
  playerBestMoves: PlayerBestMove[];
  aiCandidateMoves: Array<{ row: number; col: number; visits: number; winRate: number; raveRate: number }>;
  playerThreats: Record<string, number>;
  aiThreats: Record<string, number>;
  scoringAnalysis: ScoringAnalysis | null;
  // New enriched analysis
  moveQuality: 'optimal' | 'strong' | 'alternative' | 'tactical';
  criticalSquares: CriticalSquare[];
  boardControl: { playerInfluence: number; aiInfluence: number; contested: number; totalCells: number };
  tempo: { playerInitiative: number; aiInitiative: number; urgency: 'none' | 'defend' | 'critical' | 'attack' };
  moveNumber: number;
}

const DIRS: readonly [number, number][] = [[0, 1], [1, 0], [1, 1], [1, -1]];

// 8-connected neighbors for adjacency
const ADJ8: readonly [number, number][] = [
  [-1, -1], [-1, 0], [-1, 1],
  [0, -1],           [0, 1],
  [1, -1],  [1, 0],  [1, 1],
];

// ---- Per-player cell threat data ----
interface CellThreat {
  bestConsec: number;   // best consecutive count across 4 dirs
  secondConsec: number; // second-best
  bestOpenEnds: number; // open-end count for best dir
  secondOpenEnds: number;
}

export function categorize(consec: number, openEnds: number, wl: number): ThreatCategory {
  if (consec >= wl) return ThreatCategory.FIVE;
  if (consec === wl - 1) {
    if (openEnds >= 2) return ThreatCategory.OPEN_FOUR; // both ends open
    if (openEnds >= 1) return ThreatCategory.SIMPLE_FOUR; // one end open
    return ThreatCategory.SIMPLE_FOUR; // closed four is still a four
  }
  if (consec === wl - 2) {
    if (openEnds >= 2) return ThreatCategory.OPEN_THREE;
    if (openEnds >= 1) return ThreatCategory.OPEN_THREE; // still "open" with 1 end
    return ThreatCategory.SIMPLE_THREE;
  }
  if (consec === wl - 3 && openEnds >= 1) return ThreatCategory.BROKEN_THREE;
  if (consec >= 2) return ThreatCategory.NON_FORCING;
  return ThreatCategory.NONE;
}

// ---- Threat scoring (exponential) ----
function threatScore(bestConsec: number, secondConsec: number): number {
  return 1.5 * Math.pow(1.8, bestConsec) + Math.pow(1.8, secondConsec);
}

// ---- Scan a single cell for one player ----
function scanCellForPlayer(
  board: CellValue[][], size: number, r: number, c: number, player: Player,
): CellThreat {
  const opponent = player === 1 ? 2 : 1;
  let bestConsec = 0, secondConsec = 0;
  let bestOpenEnds = 0, secondOpenEnds = 0;

  for (const [dr, dc] of DIRS) {
    // Count consecutive own pieces in both directions from (r,c)
    let a = 0;
    for (let s = 1; s < size; s++) {
      const nr = r + dr * s, nc = c + dc * s;
      if (nr < 0 || nr >= size || nc < 0 || nc >= size) break;
      if (board[nr][nc] !== player) break;
      a++;
    }
    let b = 0;
    for (let s = 1; s < size; s++) {
      const nr = r - dr * s, nc = c - dc * s;
      if (nr < 0 || nr >= size || nc < 0 || nc >= size) break;
      if (board[nr][nc] !== player) break;
      b++;
    }

    const totalConsec = a + b;
    // Count open ends: an end is "open" if the cell beyond is not opponent/wall
    const aEndR = r + dr * (a + 1), aEndC = c + dc * (a + 1);
    const aOpen = aEndR >= 0 && aEndR < size && aEndC >= 0 && aEndC < size && board[aEndR][aEndC] !== opponent;
    const bEndR = r - dr * (b + 1), bEndC = c - dc * (b + 1);
    const bOpen = bEndR >= 0 && bEndR < size && bEndC >= 0 && bEndC < size && board[bEndR][bEndC] !== opponent;
    const openEnds = (aOpen ? 1 : 0) + (bOpen ? 1 : 0);

    // Keep top 2 directions by consecutive count
    if (totalConsec > bestConsec) {
      secondConsec = bestConsec;
      secondOpenEnds = bestOpenEnds;
      bestConsec = totalConsec;
      bestOpenEnds = openEnds;
    } else if (totalConsec > secondConsec) {
      secondConsec = totalConsec;
      secondOpenEnds = openEnds;
    }
  }

  return { bestConsec, secondConsec, bestOpenEnds, secondOpenEnds };
}

export class ThreatBoard {
  size: number;
  wl: number;
  private board: CellValue[][] | null = null;

  // Per-player threat data for all empty cells
  private playerThreats: Map<number, CellThreat> = new Map();
  private aiThreats: Map<number, CellThreat> = new Map();

  constructor(size: number, winLength: number) {
    this.size = size;
    this.wl = winLength;
  }

  buildFromBoard(board: CellValue[][], playerPiece: Player = 1, aiPiece: Player = 2): void {
    this.board = board;
    this.playerThreats.clear();
    this.aiThreats.clear();

    for (let r = 0; r < this.size; r++) {
      for (let c = 0; c < this.size; c++) {
        if (board[r][c] !== 0) continue;
        const base = r * this.size + c;
        this.playerThreats.set(base, scanCellForPlayer(board, this.size, r, c, playerPiece));
        this.aiThreats.set(base, scanCellForPlayer(board, this.size, r, c, aiPiece));
      }
    }
  }

  // ---- Compute player's best moves (from player's perspective) ----
  computePlayerBestMoves(playerPiece: Player): PlayerBestMove[] {
    if (!this.board) return [];
    const threatMap = playerPiece === 1 ? this.playerThreats : this.aiThreats;
    const center = (this.size - 1) / 2;
    const candidates: PlayerBestMove[] = [];

    for (const [base, ct] of threatMap) {
      const score = threatScore(ct.bestConsec, ct.secondConsec);
      if (score <= 1.5 && ct.bestConsec < 2) continue; // skip dead cells

      const cat1 = ct.bestConsec > 0 ? categorize(ct.bestConsec, ct.bestOpenEnds, this.wl) : ThreatCategory.NONE;
      const cat2 = ct.secondConsec > 0 ? categorize(ct.secondConsec, ct.secondOpenEnds, this.wl) : ThreatCategory.NONE;
      const isFork = THREAT_INFO[cat1]?.severity >= 3 && THREAT_INFO[cat2]?.severity >= 3 && cat1 !== cat2;

      // Adjacency: count friendly neighbors (all 8 directions)
      const r = Math.floor(base / this.size);
      const c = base % this.size;
      let adjCount = 0;
      for (const [dr, dc] of ADJ8) {
        const nr = r + dr, nc = c + dc;
        if (nr >= 0 && nr < this.size && nc >= 0 && nc < this.size && this.board![nr][nc] === playerPiece) {
          adjCount++;
        }
      }

      // Center bonus
      const centerDist = Math.sqrt((r - center) ** 2 + (c - center) ** 2);
      const centerBonus = Math.max(0, 10 - centerDist);

      const strategicScore = score * 3 + adjCount * 2 + centerBonus;
      const bestThreat = THREAT_INFO[cat1]?.name || 'None';
      const description = describeMove(cat1, cat2, isFork, ct.bestConsec);

      candidates.push({
        row: r, col: c, score, bestCat: cat1, secondCat: cat2,
        bestThreat, isFork, strategicScore, description,
      });
    }

    candidates.sort((a, b) => b.strategicScore - a.strategicScore);
    return candidates.slice(0, 5);
  }

  // ---- Position analysis: per-player threat counts + eval ----
  computePositionAnalysis(playerPiece: Player): {
    evalScore: number;
    winProb: number;
    assessment: string;
    playerThreats: Record<string, number>;
    aiThreats: Record<string, number>;
  } {
    if (!this.board) return {
      evalScore: 0, winProb: 50, assessment: 'Even',
      playerThreats: {}, aiThreats: {},
    };

    const pThreats: Record<string, number> = {};
    const aThreats: Record<string, number> = {};
    let playerTotal = 0;
    let aiTotal = 0;

    // Scan player threats
    for (const [, ct] of this.playerThreats) {
      const cat = ct.bestConsec > 0 ? categorize(ct.bestConsec, ct.bestOpenEnds, this.wl) : ThreatCategory.NONE;
      if (cat >= ThreatCategory.SIMPLE_THREE) {
        const name = THREAT_INFO[cat]?.name || 'Unknown';
        pThreats[name] = (pThreats[name] || 0) + 1;
        playerTotal += THREAT_INFO[cat]?.severity ** 2 || 0;
      }
    }

    // Scan AI threats
    for (const [, ct] of this.aiThreats) {
      const cat = ct.bestConsec > 0 ? categorize(ct.bestConsec, ct.bestOpenEnds, this.wl) : ThreatCategory.NONE;
      if (cat >= ThreatCategory.SIMPLE_THREE) {
        const name = THREAT_INFO[cat]?.name || 'Unknown';
        aThreats[name] = (aThreats[name] || 0) + 1;
        aiTotal += THREAT_INFO[cat]?.severity ** 2 || 0;
      }
    }

    // Count total pieces for positional bonus
    let playerPieces = 0, aiPieces = 0;
    for (let r = 0; r < this.size; r++) {
      for (let c = 0; c < this.size; c++) {
        if (this.board[r][c] === playerPiece) playerPieces++;
        else if (this.board[r][c] !== 0) aiPieces++;
      }
    }

    const diff = (playerTotal - aiTotal) + (playerPieces - aiPieces) * 0.5;
    const winProb = Math.max(5, Math.min(95, 50 + diff * 1.5));

    let assessment = 'Even';
    if (diff > 20) assessment = 'Winning';
    else if (diff > 8) assessment = 'Strong +';
    else if (diff > 3) assessment = 'Slight +';
    else if (diff < -20) assessment = 'Losing';
    else if (diff < -8) assessment = 'Strong -';
    else if (diff < -3) assessment = 'Slight -';

    return { evalScore: Math.round(diff), winProb: Math.round(winProb), assessment, playerThreats: pThreats, aiThreats: aThreats };
  }

  // ---- Compute critical squares ----
  computeCriticalSquares(playerPiece: Player): CriticalSquare[] {
    if (!this.board) return [];
    const aiPiece = playerPiece === 1 ? 2 : 1;
    const criticals: CriticalSquare[] = [];
    const seen = new Set<number>();

    const addCritical = (r: number, c: number, reason: string, severity: CriticalSquare['severity'], forPlayer: CriticalSquare['forPlayer']) => {
      const key = r * this.size + c;
      if (seen.has(key)) {
        const existing = criticals.find(s => s.row === r && s.col === c);
        if (existing) {
          if (severity === 'vital') existing.severity = 'vital';
          if (forPlayer === 'both') existing.forPlayer = 'both';
          else if (existing.forPlayer !== 'both') existing.forPlayer = forPlayer;
        }
        return;
      }
      seen.add(key);
      criticals.push({ row: r, col: c, reason, severity, forPlayer });
    };

    // Check player threats for must-play squares
    for (const [base, ct] of this.playerThreats) {
      const cat = ct.bestConsec > 0 ? categorize(ct.bestConsec, ct.bestOpenEnds, this.wl) : ThreatCategory.NONE;
      const r = Math.floor(base / this.size);
      const c = base % this.size;
      if (cat === ThreatCategory.OPEN_FOUR) addCritical(r, c, 'Block open four', 'vital', 'player');
      else if (cat === ThreatCategory.SIMPLE_FOUR) addCritical(r, c, 'Block four', 'vital', 'player');
      else if (cat === ThreatCategory.OPEN_THREE) addCritical(r, c, 'Disrupt open three', 'important', 'player');
    }

    // Check AI threats
    for (const [base, ct] of this.aiThreats) {
      const cat = ct.bestConsec > 0 ? categorize(ct.bestConsec, ct.bestOpenEnds, this.wl) : ThreatCategory.NONE;
      const r = Math.floor(base / this.size);
      const c = base % this.size;
      if (cat === ThreatCategory.OPEN_FOUR) addCritical(r, c, 'Claim open four', 'vital', 'ai');
      else if (cat === ThreatCategory.SIMPLE_FOUR) addCritical(r, c, 'Extend to four', 'vital', 'ai');
      else if (cat === ThreatCategory.OPEN_THREE) addCritical(r, c, 'Build open three', 'important', 'ai');
    }

    // Find contested squares (high value for both)
    const playerThreats = this.playerThreats;
    const aiThreats = this.aiThreats;
    for (const [base] of playerThreats) {
      if (aiThreats.has(base)) {
        const r = Math.floor(base / this.size);
        const c = base % this.size;
        addCritical(r, c, 'Contested square', 'important', 'both');
      }
    }

    // Sort by severity
    const order = { vital: 0, important: 1, noteworthy: 2 };
    criticals.sort((a, b) => order[a.severity] - order[b.severity]);
    return criticals.slice(0, 8);
  }

  // ---- Compute board control (influence-based) ----
  computeBoardControl(playerPiece: Player): { playerInfluence: number; aiInfluence: number; contested: number; totalCells: number } {
    if (!this.board) return { playerInfluence: 0, aiInfluence: 0, contested: 0, totalCells: 0 };
    const aiPiece = playerPiece === 1 ? 2 : 1;
    let playerInfluence = 0;
    let aiInfluence = 0;
    let contested = 0;
    let emptyCells = 0;

    for (let r = 0; r < this.size; r++) {
      for (let c = 0; c < this.size; c++) {
        if (this.board[r][c] !== 0) continue;
        emptyCells++;
        let pInf = 0, aInf = 0;
        // Check 2-cell radius influence
        for (let dr = -2; dr <= 2; dr++) {
          for (let dc = -2; dc <= 2; dc++) {
            if (dr === 0 && dc === 0) continue;
            const nr = r + dr, nc = c + dc;
            if (nr < 0 || nr >= this.size || nc < 0 || nc >= this.size) continue;
            const dist = Math.abs(dr) + Math.abs(dc);
            const weight = dist <= 1 ? 3 : 1;
            if (this.board[nr][nc] === playerPiece) pInf += weight;
            else if (this.board[nr][nc] === aiPiece) aInf += weight;
          }
        }
        if (pInf > aInf + 2) playerInfluence++;
        else if (aInf > pInf + 2) aiInfluence++;
        else if (pInf > 0 && aInf > 0) contested++;
      }
    }
    return { playerInfluence, aiInfluence, contested, totalCells: emptyCells };
  }

  // ---- Build full analysis object ----
  buildFullAnalysis(
    aiMove: [number, number] | null,
    mctsChildren?: Array<{ move: number; visits: number; winRate: number; raveRate: number }>,
    tacticalReason?: string,
    playerPiece: Player = 1,
  ): FullAnalysis {
    const posAnalysis = this.computePositionAnalysis(playerPiece);
    const playerMoves = this.computePlayerBestMoves(playerPiece);

    const aiCandidateMoves = (mctsChildren || []).slice(0, 5).map(c => {
      const row = Math.floor(c.move / this.size);
      const col = c.move % this.size;
      return { row, col, visits: c.visits, winRate: c.winRate, raveRate: c.raveRate };
    });

    let aiReasoning = tacticalReason || '';
    if (!aiReasoning && mctsChildren && mctsChildren.length > 0) {
      const top = mctsChildren[0];
      const row = Math.floor(top.move / this.size);
      const col = top.move % this.size;
      const letter = coordLabel(row, col, this.size);
      aiReasoning = `MCTS selected ${letter} — ${top.visits} visits, ${top.winRate.toFixed(1)}% win rate`;
    }
    if (!aiReasoning && aiMove) {
      aiReasoning = `Played ${coordLabel(aiMove[0], aiMove[1], this.size)}`;
    }

    // Move quality: compare AI actual move to MCTS top pick
    let moveQuality: FullAnalysis['moveQuality'] = 'optimal';
    if (tacticalReason) {
      moveQuality = 'tactical';
    } else if (mctsChildren && mctsChildren.length > 0 && aiMove) {
      const topMove = mctsChildren[0].move;
      const actualMoveIdx = aiMove[0] * this.size + aiMove[1];
      if (topMove === actualMoveIdx) {
        moveQuality = 'optimal';
      } else {
        const actualIdx = mctsChildren.findIndex(c => c.move === actualMoveIdx);
        if (actualIdx >= 0 && actualIdx <= 2) moveQuality = 'strong';
        else moveQuality = 'alternative';
      }
    }

    // Critical squares
    const criticalSquares = this.computeCriticalSquares(playerPiece);

    // Board control
    const boardControl = this.computeBoardControl(playerPiece);

    // Tempo / initiative
    const playerHighThreats = Object.entries(posAnalysis.playerThreats).reduce((s, [k, v]) => {
      if (k.includes('Four') || k.includes('Five')) return s + v * 3;
      if (k.includes('Three')) return s + v;
      return s;
    }, 0);
    const aiHighThreats = Object.entries(posAnalysis.aiThreats).reduce((s, [k, v]) => {
      if (k.includes('Four') || k.includes('Five')) return s + v * 3;
      if (k.includes('Three')) return s + v;
      return s;
    }, 0);
    const playerInitiative = Math.min(10, playerHighThreats);
    const aiInitiative = Math.min(10, aiHighThreats);
    let urgency: FullAnalysis['tempo']['urgency'] = 'none';
    if (aiHighThreats >= 6) urgency = 'critical';
    else if (aiHighThreats >= 3) urgency = 'defend';
    else if (playerHighThreats >= 4) urgency = 'attack';

    return {
      evalScore: posAnalysis.evalScore,
      winProb: posAnalysis.winProb,
      assessment: posAnalysis.assessment,
      aiReasoning,
      playerBestMoves: playerMoves,
      aiCandidateMoves,
      playerThreats: posAnalysis.playerThreats,
      aiThreats: posAnalysis.aiThreats,
      scoringAnalysis: null,
      moveQuality,
      criticalSquares,
      boardControl,
      tempo: { playerInitiative, aiInitiative, urgency },
      moveNumber: 0,
    };
  }
}

// ---- Coordinate label (skip 'I' like Go) ----
export function coordLabel(row: number, col: number, size: number): string {
  const letter = String.fromCharCode(65 + (col >= 8 ? col + 1 : col));
  return `${letter}${size - row}`;
}

// ---- Move description ----
function describeMove(cat1: ThreatCategory, cat2: ThreatCategory, isFork: boolean, consec: number): string {
  if (cat1 === ThreatCategory.FIVE) return 'Wins the game!';
  if (cat1 === ThreatCategory.OPEN_FOUR) return 'Unstoppable open four';
  if (cat1 === ThreatCategory.SIMPLE_FOUR && isFork) return 'Double threat fork';
  if (cat1 === ThreatCategory.SIMPLE_FOUR) return 'Forces response (four)';
  if (isFork) return 'Double threat fork';
  if (cat1 === ThreatCategory.OPEN_THREE) return 'Open three';
  if (cat1 === ThreatCategory.BROKEN_THREE) return 'Broken three';
  if (cat1 === ThreatCategory.SIMPLE_THREE) return 'Simple three';
  if (consec >= 2) return 'Develops position';
  return 'Center control';
}

// ============================================================
// Scoring Analysis
// ============================================================

interface ScoringBoardLike {
  boardSize: number;
  moveCount: number;
  scoreMoveFast: (r: number, c: number, p: Player) => number;
}

export function buildScoringAnalysis(
  boardLike: ScoringBoardLike,
  playerPiece: Player,
  aiPiece: Player,
  playerScore: { total: number; breakdown: { triples: number; fours: number; fives: number; crossPatterns: number; lineBreaks: number; [key: string]: number } },
  aiScore: { total: number; breakdown: { triples: number; fours: number; fives: number; crossPatterns: number; lineBreaks: number; [key: string]: number } },
  board2D?: CellValue[][],
): ScoringAnalysis {
  const size = boardLike.boardSize;
  const totalCells = size * size;
  const remainingMoves = totalCells - boardLike.moveCount;
  const boardFillPct = Math.round((boardLike.moveCount / totalCells) * 100);

  const playerMovesMade = Math.ceil(boardLike.moveCount / 2);
  const aiMovesMade = Math.floor(boardLike.moveCount / 2);
  const playerPace = playerMovesMade > 0 ? +(playerScore.total / playerMovesMade).toFixed(1) : 0;
  const aiPace = aiMovesMade > 0 ? +(aiScore.total / aiMovesMade).toFixed(1) : 0;
  const remainingPlayerMoves = Math.ceil(remainingMoves / 2);
  const remainingAiMoves = Math.floor(remainingMoves / 2);
  const projectedPlayerFinal = playerScore.total + Math.round(playerPace * remainingPlayerMoves);
  const projectedAiFinal = aiScore.total + Math.round(aiPace * remainingAiMoves);

  // Scan top scoring moves
  const playerScoring: Array<{ row: number; col: number; points: number; patterns: string }> = [];
  const aiScoring: Array<{ row: number; col: number; points: number; patterns: string }> = [];

  if (board2D) {
    for (let r = 0; r < size; r++) {
      for (let c = 0; c < size; c++) {
        if (board2D[r][c] !== 0) continue;
        const pPts = boardLike.scoreMoveFast(r, c, playerPiece);
        if (pPts > 0) {
          playerScoring.push({ row: r, col: c, points: pPts, patterns: describeScoringPatterns(board2D, size, r, c, playerPiece) });
        }
        const aPts = boardLike.scoreMoveFast(r, c, aiPiece);
        if (aPts > 0) {
          aiScoring.push({ row: r, col: c, points: aPts, patterns: describeScoringPatterns(board2D, size, r, c, aiPiece) });
        }
      }
    }
    playerScoring.sort((a, b) => b.points - a.points);
    aiScoring.sort((a, b) => b.points - a.points);
  }

  return {
    playerTotal: playerScore.total,
    aiTotal: aiScore.total,
    diff: playerScore.total - aiScore.total,
    topScoringMoves: playerScoring.slice(0, 5),
    topAiScoringMoves: aiScoring.slice(0, 5),
    playerPace,
    aiPace,
    remainingMoves,
    projectedPlayerFinal,
    projectedAiFinal,
    playerBreakdown: {
      triples: playerScore.breakdown.triples,
      fours: playerScore.breakdown.fours,
      fives: playerScore.breakdown.fives,
      crosses: playerScore.breakdown.crossPatterns,
      lineBreaks: playerScore.breakdown.lineBreaks,
    },
    aiBreakdown: {
      triples: aiScore.breakdown.triples,
      fours: aiScore.breakdown.fours,
      fives: aiScore.breakdown.fives,
      crosses: aiScore.breakdown.crossPatterns,
      lineBreaks: aiScore.breakdown.lineBreaks,
    },
    boardFillPct,
  };
}

/**
 * Describe what scoring patterns a move would create by scanning runs.
 * Returns human-readable text like "4-in-row + Cross" or "3-in-row".
 */
function describeScoringPatterns(
  board: CellValue[][], size: number, row: number, col: number, player: Player,
): string {
  const parts: string[] = [];
  let hasH3 = false, hasV3 = false;

  for (const [dr, dc] of DIRS) {
    let runLen = 1;
    for (let s = 1; s < size; s++) {
      const r = row + dr * s, c = col + dc * s;
      if (r < 0 || r >= size || c < 0 || c >= size || board[r][c] !== player) break;
      runLen++;
    }
    for (let s = 1; s < size; s++) {
      const r = row - dr * s, c = col - dc * s;
      if (r < 0 || r >= size || c < 0 || c >= size || board[r][c] !== player) break;
      runLen++;
    }

    if (runLen >= 5) { parts.push('5-row'); }
    else if (runLen >= 4) { parts.push('4-row'); }
    else if (runLen >= 3) {
      if (dr === 0) hasH3 = true;
      else if (dc === 0) hasV3 = true;
      else { parts.push('3-row'); }
    }
  }

  if (hasH3 && hasV3) {
    // Replace individual 3-rows with "Cross" if both H and V
    const idx = parts.indexOf('3-row');
    if (idx >= 0) parts.splice(idx, 1);
    parts.push('Cross');
  } else if (hasH3 || hasV3) {
    parts.push('3-row');
  }

  // Line break detection
  const opponent: Player = player === 1 ? 2 : 1;
  for (const [dr, dc] of DIRS) {
    let oppPos = 0, oppNeg = 0;
    for (let s = 1; s < size; s++) {
      const r = row + dr * s, c = col + dc * s;
      if (r < 0 || r >= size || c < 0 || c >= size || board[r][c] !== opponent) break;
      oppPos++;
    }
    for (let s = 1; s < size; s++) {
      const r = row - dr * s, c = col - dc * s;
      if (r < 0 || r >= size || c < 0 || c >= size || board[r][c] !== opponent) break;
      oppNeg++;
    }
    if (oppPos >= 1 && oppNeg >= 1 && (oppPos + oppNeg) >= 2) {
      parts.push('Break');
      break; // only count once
    }
  }

  // Deduplicate and order by importance
  const ordered: string[] = [];
  if (parts.includes('5-row')) ordered.push('5-row');
  if (parts.includes('4-row')) ordered.push('4-row');
  if (parts.includes('Cross')) ordered.push('Cross');
  if (parts.includes('3-row')) ordered.push('3-row');
  if (parts.includes('Break')) ordered.push('Break');

  return ordered.length > 0 ? ordered.join(' + ') : '0';
}
