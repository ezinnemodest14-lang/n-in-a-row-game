// Shared in-memory game store — imported by both API routes
// so they share the same Map instance.

import { GlobalRAVE } from './global-rave';
import { GameStateInternal, type Player, type GameMode, type ScoreBreakdown, type PlayerScore } from './types';

export interface LearningEntry {
  moveNumber: number;
  simulations: number;
  thinkTimeMs: number;
  nodesExpanded: number;
  treeReused: boolean;
  totalTreeNodes: number;
  bestMoveWinRate: number;
  bestMoveRaveRate: number;
  raveBeta: number;
  raveCoverage: number;
  priorTreeVisits: number;
  // Global RAVE metrics
  globalRaveCoverage: number;
  globalRaveTotalVisits: number;
  globalRaveBestRate: number;
  // Cross-game learning metrics
  crossGameRaveInherited: boolean;
  crossGameRaveVisits: number;
}

export interface ServerGame {
  state: GameStateInternal;
  playerPiece: Player;
  aiPiece: Player;
  moveHistory: { row: number; col: number; player: Player; pointsScored?: number }[];
  status: 'playing' | 'won' | 'lost' | 'draw';
  winner: Player | 0 | null;
  winLine: [number, number][] | null;
  simulations: number;
  createdAt: number;
  gameMode: GameMode;
  mctsRoot: unknown | null;
  lastAiMove: number | null;
  globalRAVE: GlobalRAVE | null;
  learningHistory: LearningEntry[];
  // Scoring mode state
  playerScore: PlayerScore;
  aiScore: PlayerScore;
}

const GAMES_KEY = '__n_in_a_row_games__';

function getGamesMap(): Map<string, ServerGame> {
  if (!(globalThis as Record<string, unknown>)[GAMES_KEY]) {
    (globalThis as Record<string, unknown>)[GAMES_KEY] = new Map<string, ServerGame>();
  }
  return (globalThis as Record<string, unknown>)[GAMES_KEY] as unknown as Map<string, ServerGame>;
}

export const games = getGamesMap();

// ============================================================
// Cross-Game GlobalRAVE Persistence
// ============================================================
// Key insight: RAVE values are position-specific (Gelly & Silver 2007).
// A position's value depends on its geometric properties (center distance,
// line potential, adjacency patterns), not on the specific game context.
// Therefore, knowledge about positions transfers across games with the
// same board size and mode.
//
// We persist a separate GlobalRAVE table per (boardSize, gameMode) pair.
// When a new game starts, it inherits the accumulated knowledge.
// This is decayed slightly (0.9x) to prevent stale data from dominating.
// ============================================================

const CROSS_GAME_RAVE_KEY = '__n_in_a_row_cross_game_rave__';

type RaveCacheKey = string; // `${boardSize}_${gameMode}`

interface RaveCacheEntry {
  rave: GlobalRAVE;
  lastUsed: number;
  gamesPlayed: number;
}

function getCrossGameRaveMap(): Map<RaveCacheKey, RaveCacheEntry> {
  if (!(globalThis as Record<string, unknown>)[CROSS_GAME_RAVE_KEY]) {
    (globalThis as Record<string, unknown>)[CROSS_GAME_RAVE_KEY] = new Map<RaveCacheKey, RaveCacheEntry>();
  }
  return (globalThis as Record<string, unknown>)[CROSS_GAME_RAVE_KEY] as Map<RaveCacheKey, RaveCacheEntry>;
}

const crossGameRaveMap = getCrossGameRaveMap();

/**
 * Get or create a cross-game RAVE table for the given configuration.
 * Returns the GlobalRAVE instance (may be pre-populated from previous games).
 *
 * @param decay - If true (default), decays old knowledge by 0.9x to balance
 *   fresh game exploration. Set to FALSE for training — training should
 *   accumulate on top of existing data without decay.
 */
export function getCrossGameRave(boardSize: number, gameMode: GameMode, decay: boolean = true): { rave: GlobalRAVE; inherited: boolean; priorVisits: number } {
  const key = `${boardSize}_${gameMode}`;
  const totalMoves = boardSize * boardSize;

  // Lazily load pre-trained data for this specific config
  loadPretrainedForConfig(key, totalMoves);

  const entry = crossGameRaveMap.get(key);

  if (entry) {
    entry.lastUsed = Date.now();
    const priorVisits = entry.rave.totalVisits;
    // Decay old knowledge only when NOT training (i.e., when a user game starts)
    if (decay && priorVisits > 0 && entry.gamesPlayed > 0) {
      const d = 0.9;
      for (let p = 0; p < 2; p++) {
        for (let i = 0; i < totalMoves; i++) {
          entry.rave.visits[p][i] *= d;
          entry.rave.wins[p][i] *= d;
        }
      }
    }
    return { rave: entry.rave, inherited: priorVisits > 0, priorVisits: Math.round(priorVisits) };
  }

  // Create new entry
  const rave = new GlobalRAVE(totalMoves);
  crossGameRaveMap.set(key, { rave, lastUsed: Date.now(), gamesPlayed: 0 });
  return { rave, inherited: false, priorVisits: 0 };
}

/**
 * Record that a game using this configuration has completed.
 * This tracks how many games have contributed to the shared RAVE table.
 */
export function recordCrossGameCompletion(boardSize: number, gameMode: GameMode) {
  const key = `${boardSize}_${gameMode}`;
  const entry = crossGameRaveMap.get(key);
  if (entry) {
    entry.gamesPlayed++;
    entry.lastUsed = Date.now();
  }
}

const CLEANUP_INTERVAL = 10 * 60 * 1000;
let lastCleanup = Date.now();

export function cleanupOldGames() {
  const now = Date.now();
  if (now - lastCleanup < CLEANUP_INTERVAL) return;
  lastCleanup = now;

  // Clean up old game sessions
  games.forEach((game, id) => {
    if (now - game.createdAt > 30 * 60 * 1000) {
      games.delete(id);
    }
  });

  // Clean up stale cross-game RAVE tables (not used in 60 minutes)
  crossGameRaveMap.forEach((entry, key) => {
    if (now - entry.lastUsed > 60 * 60 * 1000) {
      crossGameRaveMap.delete(key);
    }
  });
}

export const emptyPlayerScore = (): PlayerScore => ({
  total: 0,
  breakdown: { triples: 0, fours: 0, fives: 0, fullRows: 0, fullCols: 0, mainDiagonal: 0, antiDiagonal: 0, crossPatterns: 0, lineBreaks: 0, total: 0 },
});

// ============================================================
// Pre-trained RAVE Data Loader (lazy per-config)
// ============================================================
// Loads RAVE data from rave-data.json on demand — only the table
// for the requested boardSize + gameMode. Avoids loading all 14
// tables at once which causes memory pressure.
// ============================================================

let pretrainFileData: Record<string, {
  totalMoves: number;
  totalUpdates: number;
  visits: number[][];
  wins: number[][];
}> | null = null;
let pretrainFileLoaded = false;
let pretrainLoadedKeys = new Set<string>();

/** Try to read the rave-data.json file (once, cached) */
function ensurePretrainFile() {
  if (pretrainFileLoaded) return;
  pretrainFileLoaded = true;
  try {
    const fs = require('fs');
    const path = require('path');
    const filePath = path.join(process.cwd(), 'rave-data.json');
    if (!fs.existsSync(filePath)) return;
    const raw = fs.readFileSync(filePath, 'utf-8');
    pretrainFileData = JSON.parse(raw);
    console.log(`[RAVE] Pre-trained file ready: ${Object.keys(pretrainFileData).length} tables available`);
  } catch (error) {
    console.error('[RAVE] Failed to read rave-data.json:', error);
    pretrainFileData = null;
  }
}

function loadPretrainedForConfig(key: string, totalMoves: number) {
  if (pretrainLoadedKeys.has(key)) return;
  ensurePretrainFile();
  if (!pretrainFileData || !pretrainFileData[key]) return;
  pretrainLoadedKeys.add(key);

  const tableData = pretrainFileData[key];
  const existing = crossGameRaveMap.get(key);

  if (existing) {
    for (let p = 0; p < 2; p++) {
      for (let i = 0; i < totalMoves; i++) {
        existing.rave.visits[p][i] += tableData.visits[p][i];
        existing.rave.wins[p][i] += tableData.wins[p][i];
      }
    }
    existing.rave.totalUpdates += tableData.totalUpdates;
  } else {
    const rave = new GlobalRAVE(totalMoves);
    for (let p = 0; p < 2; p++) {
      for (let i = 0; i < totalMoves; i++) {
        rave.visits[p][i] = tableData.visits[p][i];
        rave.wins[p][i] = tableData.wins[p][i];
      }
    }
    rave.totalUpdates = tableData.totalUpdates;
    crossGameRaveMap.set(key, { rave, lastUsed: Date.now(), gamesPlayed: 0 });
  }

  const visits = Math.round(crossGameRaveMap.get(key)!.rave.totalVisits);
  console.log(`[RAVE] Loaded ${key}: ${visits} visits`);
}

/**
 * Public API: load all pre-trained data (for training route stats).
 * Loads every table from the file.
 */
export function loadPretrainedRAVE(): { loaded: boolean; tables: number; totalVisits: number } {
  ensurePretrainFile();
  if (!pretrainFileData) return { loaded: false, tables: 0, totalVisits: 0 };

  // Load all unloaded tables
  for (const [key, tableData] of Object.entries(pretrainFileData)) {
    if (!pretrainLoadedKeys.has(key)) {
      loadPretrainedForConfig(key, tableData.totalMoves);
    }
  }

  let totalVisits = 0;
  let tables = 0;
  crossGameRaveMap.forEach((entry) => {
    totalVisits += entry.rave.totalVisits;
    tables++;
  });
  return { loaded: true, tables, totalVisits: Math.round(totalVisits) };
}
