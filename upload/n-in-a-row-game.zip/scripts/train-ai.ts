/**
 * Standalone AI training script — runs OUTSIDE Next.js to avoid Turbopack crashes.
 * 
 * Usage:
 *   bun run scripts/train-ai.ts              # 100 games per config (default)
 *   bun run scripts/train-ai.ts 200           # 200 games per config
 *   bun run scripts/train-ai.ts 20 5          # 20 games, 5 rounds (accumulate)
 * 
 * This produces a JSON file with the trained RAVE data that the server
 * can load. Or it can be used to train incrementally via the API.
 */

// ---- Inline everything (no project imports) ----

type Player = 1 | 2;
type GameMode = 'classic' | 'scoring';

const ALL_BOARD_SIZES = [3, 5, 8, 9, 10, 15, 19, 24];
const ALL_MODES: GameMode[] = ['classic', 'scoring'];

// ---- GlobalRAVE ----
class GlobalRAVE {
  visits: [Float64Array, Float64Array];
  wins: [Float64Array, Float64Array];
  totalMoves: number;
  totalUpdates: number;

  constructor(totalMoves: number) {
    this.totalMoves = totalMoves;
    this.visits = [new Float64Array(totalMoves), new Float64Array(totalMoves)];
    this.wins = [new Float64Array(totalMoves), new Float64Array(totalMoves)];
    this.totalUpdates = 0;
  }

  update(moveIdx: number, player: number, winner: number | 0): void {
    const pIdx = player - 1;
    this.visits[pIdx][moveIdx]++;
    if (winner === player) this.wins[pIdx][moveIdx] += 1;
    else if (winner === 0) this.wins[pIdx][moveIdx] += 0.5;
    this.totalUpdates++;
  }

  getRate(moveIdx: number, player: number): number {
    const v = this.visits[player - 1][moveIdx];
    return v === 0 ? 0.5 : this.wins[player - 1][moveIdx] / v;
  }

  get coverage(): number {
    let filled = 0;
    for (let i = 0; i < this.totalMoves; i++) {
      if (this.visits[0][i] > 0 || this.visits[1][i] > 0) filled++;
    }
    return filled;
  }

  get totalVisits(): number {
    let sum = 0;
    for (let p = 0; p < 2; p++) {
      for (let i = 0; i < this.totalMoves; i++) sum += this.visits[p][i];
    }
    return sum;
  }

  toJSON() {
    return {
      totalMoves: this.totalMoves,
      totalUpdates: this.totalUpdates,
      visits: [Array.from(this.visits[0]), Array.from(this.visits[1])],
      wins: [Array.from(this.wins[0]), Array.from(this.wins[1])],
    };
  }
}

// ---- Board ----
class Board {
  cells: Uint8Array;
  size: number;
  moveCount: number;
  curPlayer: Player;
  winLen: number;
  mode: GameMode;

  constructor(size: number, winLen: number, mode: GameMode) {
    this.size = size; this.winLen = winLen; this.mode = mode;
    this.cells = new Uint8Array(size * size);
    this.moveCount = 0; this.curPlayer = 1;
  }

  idx(r: number, c: number) { return r * this.size + c; }
  get(r: number, c: number) { return this.cells[this.idx(r, c)]; }

  apply(r: number, c: number) {
    this.cells[this.idx(r, c)] = this.curPlayer;
    this.moveCount++;
    this.curPlayer = (this.curPlayer === 1 ? 2 : 1) as Player;
  }

  candidates(): number[] {
    if (this.moveCount === 0) return [this.idx((this.size/2)|0, (this.size/2)|0)];
    const set = new Set<number>();
    const s = this.size;
    for (let i = 0; i < this.cells.length; i++) {
      if (this.cells[i] !== 0) {
        const r = (i / s) | 0, c = i % s;
        for (let dr = -1; dr <= 1; dr++) for (let dc = -1; dc <= 1; dc++) {
          if (!dr && !dc) continue;
          const nr = r + dr, nc = c + dc;
          if (nr >= 0 && nr < s && nc >= 0 && nc < s && this.cells[nr * s + nc] === 0)
            set.add(nr * s + nc);
        }
      }
    }
    if (set.size > 0) return Array.from(set);
    const m: number[] = [];
    for (let i = 0; i < this.cells.length; i++) if (this.cells[i] === 0) m.push(i);
    return m;
  }

  wouldWin(r: number, c: number, player: Player): boolean {
    const s = this.size, w = this.winLen;
    const ds = [[0,1],[1,0],[1,1],[1,-1]];
    for (const [dr, dc] of ds) {
      let len = 1;
      for (let i = 1; i < w; i++) { const nr=r+dr*i,nc=c+dc*i; if(nr<0||nr>=s||nc<0||nc>=s||this.cells[nr*s+nc]!==player) break; len++; }
      for (let i = 1; i < w; i++) { const nr=r-dr*i,nc=c-dc*i; if(nr<0||nr>=s||nc<0||nc>=s||this.cells[nr*s+nc]!==player) break; len++; }
      if (len >= w) return true;
    }
    return false;
  }

  checkWin(r: number, c: number): Player | 0 {
    const p = this.get(r, c); if (!p) return 0;
    const s = this.size, w = this.winLen;
    const ds = [[0,1],[1,0],[1,1],[1,-1]];
    for (const [dr, dc] of ds) {
      let len = 1;
      for (let i = 1; i < w; i++) { const nr=r+dr*i,nc=c+dc*i; if(nr<0||nr>=s||nc<0||nc>=s||this.get(nr,nc)!==p) break; len++; }
      for (let i = 1; i < w; i++) { const nr=r-dr*i,nc=c-dc*i; if(nr<0||nr>=s||nc<0||nc>=s||this.get(nr,nc)!==p) break; len++; }
      if (len >= w) return p as Player | 0;
    }
    return 0;
  }

  computeScore(p: Player): number {
    let total = 0; const s = this.size;
    const ds = [[0,1],[1,0],[1,1],[1,-1]];
    for (let r = 0; r < s; r++) for (let c = 0; c < s; c++) {
      if (this.get(r, c) !== p) continue;
      for (const [dr, dc] of ds) {
        const pr=r-dr, pc=c-dc;
        if (pr>=0&&pr<s&&pc>=0&&pc<s&&this.get(pr,pc)===p) continue;
        let len = 0, cr = r, cc = c;
        while (cr>=0&&cr<s&&cc>=0&&cc<s&&this.get(cr,cc)===p) { len++; cr+=dr; cc+=dc; }
        if (len >= 3) total += (len-2);
        if (len >= 4) total += (len-3)*5;
        if (len >= 5) total += (len-4)*15;
      }
    }
    return total;
  }
}

// ---- Play function (random playouts + tactical overrides) ----
function play(size: number, winLen: number, mode: GameMode, rave: GlobalRAVE): { winner: Player | 0; moves: number } {
  const b = new Board(size, winLen, mode);
  const hist: Array<{m: number; p: Player}> = [];
  let winner: Player | 0 = 0;

  while (b.moveCount < size * size) {
    const cands = b.candidates();
    if (!cands.length) break;
    const player = b.curPlayer;
    const opp: Player = player === 1 ? 2 : 1;
    let chosen: number | null = null;

    // TACTICAL: take winning move
    for (const m of cands) {
      const r = (m / size) | 0, c = m % size;
      if (b.wouldWin(r, c, player)) { chosen = m; break; }
    }
    // TACTICAL: block opponent's winning move
    if (chosen === null) {
      for (const m of cands) {
        const r = (m / size) | 0, c = m % size;
        if (b.wouldWin(r, c, opp)) { chosen = m; break; }
      }
    }
    // RANDOM: softmax with tiny center bias
    if (chosen === null) {
      const ctr = (size - 1) / 2;
      const scores = new Float64Array(cands.length);
      let maxS = -Infinity;
      for (let i = 0; i < cands.length; i++) {
        const r = (cands[i] / size) | 0, c = cands[i] % size;
        const dist = Math.sqrt((r-ctr)**2 + (c-ctr)**2);
        scores[i] = ctr * 0.3 - dist * 0.3 + Math.random() * 20;
        if (scores[i] > maxS) maxS = scores[i];
      }
      const temp = 5.0;
      let sum = 0;
      const probs = new Float64Array(cands.length);
      for (let i = 0; i < cands.length; i++) {
        probs[i] = Math.exp((scores[i] - maxS) / temp);
        sum += probs[i];
      }
      let r = Math.random() * sum;
      for (let i = 0; i < cands.length; i++) {
        r -= probs[i];
        if (r <= 0) { chosen = cands[i]; break; }
      }
      if (chosen === null) chosen = cands[cands.length - 1];
    }

    const row = (chosen / size) | 0, col = chosen % size;
    b.apply(row, col);
    hist.push({m: chosen, p: player});

    if (mode === 'classic') {
      const w = b.checkWin(row, col);
      if (w) { winner = w; break; }
    }
  }

  if (mode === 'scoring' && !winner) {
    const s1 = b.computeScore(1), s2 = b.computeScore(2);
    winner = s1 > s2 ? 1 : s2 > s1 ? 2 : 0;
  }

  for (const e of hist) rave.update(e.m, e.p, winner);
  return { winner, moves: hist.length };
}

// ---- Main ----
interface ConfigResult {
  boardSize: number;
  winLength: number;
  gameMode: GameMode;
  p1Wins: number; p2Wins: number; draws: number;
  avgMoves: number;
  raveVisitsBefore: number;
  raveVisitsAfter: number;
  raveCoverage: number;
}

const raveTables = new Map<string, GlobalRAVE>();

function getRave(bs: number, gm: GameMode): GlobalRAVE {
  const key = `${bs}_${gm}`;
  let rave = raveTables.get(key);
  if (!rave) {
    rave = new GlobalRAVE(bs * bs);
    raveTables.set(key, rave);
  }
  return rave;
}

// Load existing RAVE data from file to accumulate on top of previous training
function loadExistingRaveData() {
  const fs = require('fs');
  const filePath = '/home/z/my-project/rave-data.json';
  if (!fs.existsSync(filePath)) return;
  try {
    const raw = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
    let totalLoaded = 0;
    for (const [key, data] of Object.entries(raw) as [string, any][]) {
      const rave = new GlobalRAVE(data.totalMoves);
      for (let p = 0; p < 2; p++) {
        for (let i = 0; i < data.totalMoves; i++) {
          rave.visits[p][i] = data.visits[p][i];
          rave.wins[p][i] = data.wins[p][i];
        }
      }
      rave.totalUpdates = data.totalUpdates;
      raveTables.set(key, rave);
      totalLoaded += Math.round(rave.totalVisits);
    }
    if (totalLoaded > 0) {
      console.log(`Loaded ${Object.keys(raw).length} tables with ${totalLoaded} existing visits from rave-data.json`);
    }
  } catch (e) {
    console.error('Warning: could not load existing rave-data.json:', e);
  }
}

function trainConfigs(numGames: number, sizes?: number[]): ConfigResult[] {
  const results: ConfigResult[] = [];
  const boardSizes = sizes || ALL_BOARD_SIZES;
  for (const bs of boardSizes) {
    const wl = bs <= 5 ? 3 : 5;
    for (const gm of ALL_MODES) {
      const rave = getRave(bs, gm);
      const before = rave.totalVisits;
      let p1 = 0, p2 = 0, dr = 0, totalMoves = 0;
      const t0 = performance.now();

      for (let g = 0; g < numGames; g++) {
        const res = play(bs, wl, gm, rave);
        if (res.winner === 1) p1++;
        else if (res.winner === 2) p2++;
        else dr++;
        totalMoves += res.moves;
      }

      const elapsed = Math.round(performance.now() - t0);
      const after = rave.totalVisits;

      results.push({
        boardSize: bs, winLength: wl, gameMode: gm,
        p1Wins: p1, p2Wins: p2, draws: dr,
        avgMoves: Math.round(totalMoves / numGames),
        raveVisitsBefore: Math.round(before),
        raveVisitsAfter: Math.round(after),
        raveCoverage: rave.coverage,
      });
      const added = Math.round(after - before);
      const total = Math.round(after);
      const covStr = String(rave.coverage).padStart(4);
      const addedStr = String(added).padStart(5);
      const totalStr = String(total).padStart(6);
      console.log(`  ${String(bs).padStart(2)}x${bs} ${gm.padEnd(8)} | +${addedStr} visits =${totalStr} total | cov:${covStr}/${bs*bs} | ${elapsed}ms | P1=${String(p1).padStart(2)} P2=${String(p2).padStart(2)} D=${String(dr).padStart(2)}`);
    }
  }
  return results;
}

// Parse args
let sizesArg = ''; let numGamesArg = 100; let numRoundsArg = 1;
for (let i = 2; i < process.argv.length; i++) {
  if (process.argv[i] === '--sizes') { sizesArg = process.argv[++i] || ''; }
  else if (!numGamesArg && !isNaN(parseInt(process.argv[i]))) numGamesArg = parseInt(process.argv[i], 10);
  else if (numGamesArg && !numRoundsArg && numGamesArg > 0 && !isNaN(parseInt(process.argv[i]))) numRoundsArg = parseInt(process.argv[i], 10);
}
// Simpler parsing: bun run scripts/train-ai.ts [games] [rounds] [--sizes 3,5,9]
numGamesArg = parseInt(process.argv[2] || '100', 10);
numRoundsArg = parseInt(process.argv[3] || '1', 10);
sizesArg = process.argv.includes('--sizes') ? (process.argv[process.argv.indexOf('--sizes') + 1] || '') : '';

const numGames = Math.max(1, Math.min(1000000, numGamesArg));
const numRounds = Math.max(1, Math.min(100, numRoundsArg));
const boardSizes = sizesArg ? sizesArg.split(',').map(Number).filter(n => n >= 3 && n <= 30) : ALL_BOARD_SIZES;
const numConfigs = boardSizes.length * ALL_MODES.length;

console.log(`\n=== RAVE Training: ${numGames} games/config × ${numRounds} rounds (${numGames * numRounds * numConfigs} total games) ===`);
console.log(`Board sizes: [${boardSizes.join(', ')}] (${boardSizes.length} sizes × 2 modes = ${numConfigs} configs)\n`);

// Load existing data to accumulate on top of it
loadExistingRaveData();

const grandT0 = performance.now();

for (let round = 1; round <= numRounds; round++) {
  console.log(`\n--- Round ${round}/${numRounds} ---`);
  trainConfigs(numGames, boardSizes);
}

const totalMs = Math.round(performance.now() - grandT0);
const totalGames = numGames * numRounds * numConfigs;

// Save RAVE data to JSON file
const raveData: Record<string, ReturnType<GlobalRAVE['toJSON']>> = {};
for (const [key, rave] of raveTables) {
  raveData[key] = rave.toJSON();
}
const outPath = '/home/z/my-project/rave-data.json';
const fs = require('fs');
fs.writeFileSync(outPath, JSON.stringify(raveData));

console.log(`\n=== DONE ===`);
console.log(`Total: ${totalGames} games in ${(totalMs/1000).toFixed(1)}s`);
console.log(`RAVE data saved to: ${outPath}`);
console.log(`\nFinal RAVE state (ALL tables):`);
for (const [key, rave] of [...raveTables].sort((a, b) => a[0].localeCompare(b[0]))) {
  const [bs, gm] = key.split('_');
  console.log(`  ${String(bs).padStart(2)}x${String(bs).padEnd(2)} ${gm.padEnd(8)} | visits: ${String(Math.round(rave.totalVisits)).padStart(7)} | coverage: ${String(rave.coverage).padStart(4)}/${(+bs)*(+bs)}`);
}
console.log('');
let grandTotal = 0;
for (const rave of raveTables.values()) grandTotal += rave.totalVisits;
console.log(`Grand total visits across all tables: ${Math.round(grandTotal).toLocaleString()}`);
