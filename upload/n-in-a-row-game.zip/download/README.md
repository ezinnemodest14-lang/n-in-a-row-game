# N-in-a-Row: AI-Powered Strategy Game

## Complete Project Archive — Windows Ready

**Archive:** `n-in-a-row-game.zip` (263 KB source, dependencies install via npm/bun)
**Platform:** Windows, macOS, Linux
**Framework:** Next.js 16 + TypeScript 5 + Tailwind CSS 4
**Last Updated:** September 2025

---

## Quick Start on Windows

### Prerequisites
- **Node.js** 18+ (recommended: 20 LTS) — https://nodejs.org
- OR **Bun** 1.3+ (faster) — https://bun.sh
- npm or bun package manager

### Installation
```bash
# 1. Extract the zip to a folder
# 2. Open Command Prompt / PowerShell in that folder

# Using npm:
npm install

# OR using bun (faster):
bun install

# 3. Initialize the database
npx prisma db push
# OR: bunx prisma db push

# 4. Start the development server
npm run dev
# OR: bun run dev

# 5. Open http://localhost:3000 in your browser
```

### Production Build
```bash
npm run build
npm run start
```

---

## Project Architecture

```
n-in-a-row-game/
├── src/
│   ├── app/
│   │   ├── page.tsx              # Main game page (layout: toolbar, board, eval bar, bottom panel)
│   │   ├── layout.tsx             # Root layout with fonts and providers
│   │   ├── globals.css            # Global styles + custom scrollbar + acrylic utilities
│   │   └── api/
│   │       └── game/
│   │           ├── new/route.ts     # POST: Create new game
│   │           ├── move/route.ts    # POST: Player move + AI response (full MCTS)
│   │           └── train/route.ts   # POST: Run AI self-training
│   ├── components/
│   │   ├── game/
│   │   │   ├── Board.tsx            # Game board (85% viewport, click-to-play, last-move highlight)
│   │   │   ├── EvalBar.tsx          # Vertical evaluation bar (gradient fill, score display)
│   │   │   ├── QuickPreview.tsx      # Side hover panel (slide-in, 300ms delay, eval+threats)
│   │   │   ├── AnalysisPanel.tsx    # Bottom panel: status bar + collapsible 14-section analysis
│   │   │   ├── Toolbar.tsx          # Top bar (new game, auto-mode, settings, stats, AI training)
│   │   │   ├── Settings.tsx         # Game settings (board size, win length, AI difficulty, game mode)
│   │   │   ├── GameInfo.tsx          # Stats sheet (win/loss/draw, learning progress, move history)
│   │   │   └── ArchInfo.tsx          # Architecture info overlay
│   │   └── ui/                     # 50+ shadcn/ui components (New York style)
│   ├── lib/
│   │   ├── game/
│   │   │   ├── mcts.ts              # MCTS + RAVE search engine (784 lines)
│   │   │   ├── threat-classifier.ts  # Pattern recognition (662 lines)
│   │   │   ├── types.ts             # All TypeScript types and interfaces (585 lines)
│   │   │   ├─│   │   │   ├── server-games.ts      # In-memory game session management
│   │   │   ├── global-rave.ts        # RAVE global learning tables + persistence
│   │   │   └── training-engine.ts   # AI self-training engine
│   │   ├── db.ts                    # Prisma client singleton
│   │   └── utils.ts                 # cn() utility (clsx + tailwind-merge)
│   └── store/
│       └── game-store.ts          # Zustand store (542 lines) — all game state + actions
├── prisma/
│   └── schema.prisma           # Database schema (GameSession, Move, LearningData)
├── db/
│   └── custom.db               # SQLite database
├── public/
│   ├── robots.txt
│   └── logo.svg
├── scripts/
│   └── train-ai.ts            # Standalone AI training script
├── rave-data.json             # Pre-trained RAVE tables (16 boards, 86K+ visits)
├── package.json                # Dependencies and scripts
├── bun.lock                    # Lock file (use npm install on Windows if no bun)
├── tsconfig.json               # TypeScript configuration
├── tailwind.config.ts           # Tailwind CSS 4 configuration
├── next.config.ts              # Next.js configuration
├── postcss.config.mjs          # PostCSS configuration
├── components.json             # shadcn/ui configuration
└── .env                        # Environment variables
```

### Total Source: ~12,334 lines of TypeScript/TSX
### Core Game AI: ~3,680 lines (MCTS, threat classifier, types, store, API routes)

---

## AI Engine: MCTS + RAVE + Threat Classifier

### Monte Carlo Tree Search (MCTS)
- **Algorithm:** UCT (Upper Confidence Bound for Trees) with RAVE (Rapid Action Value Estimation)
- **Paper Reference:** Gelly & Silver (2007) — Combining Online and Offline Knowledge in UCT
- **Simulations:** 3,000 per move (configurable)
- **Time Limit:** 4,000ms wall-clock per move
- **Tree Reuse:** Search tree carries forward between moves within a game

### RAVE (Rapid Action Value Estimation)
- **Purpose:** Accelerates MCTS convergence by sharing knowledge about move quality across the tree
- **Global RAVE:** Learns from ALL games played (persists to `rave-data.json`)
- **Pre-trained Data:** 16 board configurations with 86,000+ total visits loaded at startup
- **Beta Schedule:** AMAF + RAVE heuristic blend decreases over time as MCTS confidence grows

### Threat Classifier
- **Pattern Recognition:** Scans all 4 directions (horizontal, vertical, 2 diagonals)
- **Classifies:** Open Five, Half-Open Five, Open Four, Half-Open Four, Open Three, Half-Open Three, Open Two
- **Threat Levels:** vital (must block), important (should consider), optional
- **Fork Detection:** Identifies moves that create multiple threats simultaneously
- **Move Ordering:** Prioritizes moves near existing threats for faster MCTS convergence
- **Scoring Analysis:** In Score Attack mode, evaluates point potential of each position

### Global Learning
- Moves played across all games update global RAVE tables
- Learning data persists to `rave-data.json` (loaded on startup)
- AI gets stronger the more you play
- Training script (`scripts/train-ai.ts`) for offline self-play

---

## Game Features

### Gameplay Modes
- **Classic Mode:** First to get N-in-a-row wins (configurable: 3, 4, 5, 6)
- **Score Attack Mode:** Earn points for patterns (3pts/triple, 4pts/four, 5pts/five). Highest score when board is full wins.

### Board Configuration
- **Board Size:** 9×9, 11×11, 13×13, 15×15, 19×19
- **Win Length:** 3, 4, 5, 6 (in-a-row needed to win)
- **AI Difficulty:** Easy (500 sims), Medium (1500 sims), Hard (3000 sims)

### Analysis & Visualization
- **Eval Bar:** Vertical gradient bar showing real-time position evaluation (green = player advantage, dark = AI advantage)
- **Quick Preview (Side Panel):** Hover the EvalBar area to reveal a slide-in panel with:
  - Eval score and win probability
  - Strategic narrative
  - Tempo/urgency indicator
  - Last move analysis
  - Critical squares
  - Threat summary
  - Board control percentages
  - Key positions
  - Search statistics
- **Bottom Analysis Panel:** Unified bottom panel with acrylic/glassmorphism styling containing:
  - Status bar (You vs AI, turn indicator, score display, move count)
  - 14 collapsible analysis sections (Strategic Overview, Position Eval, Move Assessment, AI Reasoning, Move Timeline, Critical Squares, Score Board, Best Moves, AI Considered, Threat Analysis, Board Control, AI Search Performance, Pattern Learning & RAVE, Rules & Context)
  - Footer with AI engine description

### Auto Mode
- Toggle auto-play: AI plays against itself continuously
- Useful for training and watching the AI learn
- Auto-restarts after each game ends

### UI/UX Design
- **Acrylic/Glassmorphism:** `bg-white/60 backdrop-blur-2xl border border-white/40` for panels
- **Responsive:** Mobile-first design with breakpoints for sm/md/lg/xl
- **Animations:** Framer Motion for panel transitions, bar animations, collapsible sections
- **Color System:** Tailwind CSS variables, no blue/indigo defaults
- **Board:** 85% viewport cap, coordinate labels (A-P, 1-19), last-move highlight ring
- **Sticky Footer:** Bottom panel always visible at viewport bottom

---

## Technology Stack

| Layer | Technology | Version |
|-------|-----------|---------|
| Framework | Next.js (App Router) | 16.1.x |
| Language | TypeScript | 5.x |
| Styling | Tailwind CSS 4 | 4.x |
| UI Components | shadcn/ui (New York) | Latest |
| Icons | Lucide React | 0.525.x |
| State Management | Zustand | 5.0.x |
| Server State | TanStack Query | 5.82.x |
| Animations | Framer Motion | 12.x |
| Database | Prisma + SQLite | 6.11.x |
| Auth | NextAuth.js | 4.24.x (available) |
| Form Handling | React Hook Form + Zod | 7.60.x / 4.0.x |

---

## API Endpoints

| Method | Route | Description |
|--------|-------|-------------|
| POST | `/api/game/new` | Create a new game session. Returns board state, game ID, player piece assignment. |
| POST | `/api/game/move` | Submit player move, receive AI response. Full MCTS search runs server-side. Returns updated board, analysis, AI move. |
| POST | `/api/game/train` | Trigger AI self-training. Runs configurable number of self-play games to strengthen RAVE tables. |

---

## Development Timeline

### Phase 1: Foundation (Initial Build)
- Next.js 16 project scaffold with App Router
- Prisma + SQLite database setup
- shadcn/ui component library integration (50+ components)
- Tailwind CSS 4 configuration with custom theme
- Zustand state management store

### Phase 2: Core Game Engine
- **MCTS implementation** (784 lines): UCT selection, expansion, simulation, backpropagation
- **RAVE integration**: AMAF heuristic, beta scheduling, global RAVE tables
- **Threat classifier** (662 lines): Pattern scanning, threat classification, fork detection
- **Type system** (585 lines): FullAnalysis, PlayerBestMove, ScoringAnalysis, CriticalSquare, etc.
- **Server-side game sessions**: In-memory game state with auto-cleanup
- **API routes**: New game, player move + AI response, training endpoint

### Phase 3: UI Components
- **Board component** (347 lines): 85% viewport cap, click-to-play, coordinate labels, last-move highlight, loading overlay
- **EvalBar** (vertical gradient evaluation bar): Real-time position score visualization
- **Toolbar**: New game, auto-mode toggle, settings/stats sheets
- **Settings panel**: Board size, win length, AI difficulty, game mode (classic/score attack)

### Phase 4: Analysis System
- **QuickPreview** (312 lines): Side hover panel with 300ms delay, comprehensive analysis display
- **AnalysisPanel** (780 lines): 14-section collapsible analysis with acrylic styling
  - Strategic Overview (AI-generated narrative)
  - Position Evaluation (score + win probability bar)
  - Move Assessment (quality rating + urgency)
  - AI Reasoning (natural language explanation)
  - Move Timeline (last 8 moves with phase labels)
  - Critical Squares (vital/important/optional)
  - Score Board (scoring mode breakdown)
  - Best Moves (player options with fork detection)
  - AI Considered (visit counts, win rates)
  - Threat Analysis (player + AI threat breakdown)
  - Board Control (influence percentages)
  - AI Search Performance (simulations, think time, throughput)
  - Pattern Learning & RAVE (coverage, tree reuse, RAVE influence)
  - Rules & Context
- **BottomPanel**: Unified bottom panel merging status bar + analysis + footer with acrylic styling

### Phase 5: Polish & Reliability
- Auto-recovery from server disconnections ("Game not found" retry logic)
- AI move validation (triple safety: MCTS selection, best-move check, API route validation)
- Optimistic player piece rendering (instant visual feedback)
- Loading overlay during game initialization
- Auto-game-start on page load
- Auto-mode for AI self-play observation

### Phase 6: Visual Design
- Acrylic/glassmorphism panels (`bg-white/60 backdrop-blur-2xl`)
- Gradient-based board styling
- Framer Motion animations for all transitions
- Responsive design (mobile through desktop)
- Custom scrollbar styling
- Phase indicators (Opening/Midgame/Endgame badges)

### Current Status: Fully Functional
- All core gameplay working
- AI plays at competitive strength with MCTS+RAVE
- Analysis panels provide deep insights
- Global learning persists across sessions
- Pre-trained RAVE data (86K+ visits) included

---

## Known Issues & Notes

1. **Threat Classifier Shared-Array Bug**: There's a known shared-array mutation issue in `threat-classifier.ts` around lines 280-297. It works in practice due to the array being rewritten each call, but should be fixed for correctness.
2. **Server Process Stability**: In sandbox environments, background Node.js processes may be killed between tool calls. The client-side auto-recovery logic handles this gracefully.
3. **Platform-Specific Binaries**: The `node_modules` folder is NOT included in this archive because it contains Linux-specific compiled binaries. Run `npm install` on your Windows machine to get the correct Windows binaries.
4. **Database**: The included `db/custom.db` is an SQLite file from Linux. It should work on Windows, but you can regenerate it with `npx prisma db push`.

---

## File Sizes (Source Only)

| Category | Lines | Files |
|----------|-------|-------|
| Game AI Engine | 3,680 | 9 |
| UI Components (game) | 3,387 | 8 |
| UI Components (shadcn) | 5,855 | 50+ |
| Hooks & Utilities | ~150 | 3 |
| Config & Setup | ~100 | 8 |
| **Total** | **12,334** | **70+** |

---

## License

Private project. All rights reserved.
